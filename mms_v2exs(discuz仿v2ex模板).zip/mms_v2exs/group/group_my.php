<?php exit;?>
<!--{template common/header}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<!--{if $v2ex['pjax'] == 1}-->
<script>
pjax_init();
function pjax_init(){
    document.addEventListener('pjax:send', function() {
        NProgress.start();
    });
    document.addEventListener('pjax:complete', function() {
        NProgress.done();
    });
    document.addEventListener('pjax:error', function() {
    });
    document.addEventListener('pjax:success', function() {
    });
    document.addEventListener('DOMContentLoaded', function() {
        var pjax = new Pjax({
            elements: 'a.pjax',
            selectors: [
                'title',
                '#Main'
            ]
        });
    });
}
</script>
<!--{/if}-->
<style>
			.vm {
			    vertical-align: 0px;
			}
			.member-list ul {
			  margin-top: -20px;
			  letter-spacing: -0.31em;
			  *letter-spacing: normal;
			  word-spacing: -0.43em;
			  font-size: 0;
			}
			.member-list .pic {
			  margin-bottom: 5px;
			}
			.member-list li {
			  display: inline-block;
			  *display: inline;
			  zoom: 1;
			  width: 88px;
			  margin-top: 20px;
			  text-align: center;
			  font-size: 12px;
			  vertical-align: top;
			  letter-spacing: normal;
			  word-spacing: normal;
			}
			.member-list .name {
			  clear: both;
			}
			.u_actions { display:inline-block;*display:inline;zoom:1;vertical-align:middle; }
			</style>

    <div id="Wrapper">
        <div class="content">
            <div id="Leftbar"></div>
            <div id="Rightbar">
<!--{subtemplate common/1111}-->

		<!--{if helper_access::check_module('group')}-->
<div class="sep20"></div>
<div class="box"><div class="inner">
<a href="forum.php?mod=group&action=create" id="create_group_btn">＋{lang mms_v2ex:v2ex_185}{lang group}</a>
</div></div>
		<!--{/if}-->
<div class="sep20"></div>
<div class="box">
			<div class="cell">
			<strong class="gray">{lang mms_v2ex:v2ex_186}{lang group}</strong>
			</div>
    <div class="sep10"></div>
			<div class="member-list">
				<ul style="position:relative;text-align:left;">
					<!--{loop $friendgrouplist $groupid $group}-->
					<li>
						<div class="avt pic "><a href="forum.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a></div>
						<div class="name" style="width:80px;white-space:nowrap;overflow:hidden;text-overflow : ellipsis;MARGIN-RIGHT: auto; MARGIN-LEFT: auto;"><a href="forum.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
<div class="sep10"></div>
</div>
<!--{if $randgroup}-->
<div class="sep20"></div>
<div class="box">
			<div class="cell">
			<strong class="gray">{lang mms_v2ex:v2ex_133}{lang group}</strong>
			</div>
    <div class="sep10"></div>
			<div class="member-list">
				<ul style="position:relative;text-align:left;">
					<!--{loop $randgroup $key $group}-->
					<li>
						<div class="avt pic "><a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a></div>

						<div class="name" style="width:80px;white-space:nowrap;overflow:hidden;text-overflow : ellipsis;MARGIN-RIGHT: auto; MARGIN-LEFT: auto;"><a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]">$group[name]</a></div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
<div class="sep10"></div>
</div>
<!--{/if}-->
<div class="sep20"></div>
<div class="box">
    <div class="inner" align="center">
{$_G['cache']['plugin']['mms_v2ex']['mms_qjad']}
    </div>
</div>

            </div>
            <div id="Main">
                <div class="sep20"></div>
<div id="ct" class="box">
  <div class="inner" id="Tabs">
<!--{if $v2ex['mms_digest'] == 1}--><a href="forum.php?mod=guide&view=digest" class="tab">{lang mms_v2ex:v2ex_1}</a><!--{/if}--><!--{if $v2ex['mms_newthread'] == 1}--><a href="forum.php?mod=guide&view=newthread" class="tab">{lang mms_v2ex:v2ex_2}</a><!--{/if}--><!--{if $v2ex['mms_sofa'] == 1}--><a href="forum.php?mod=guide&view=sofa" class="tab">{lang mms_v2ex:v2ex_3}</a><!--{/if}--><!--{if $v2ex['mms_share'] == 1}--><a href="home.php?mod=space&do=share&view=all" class="tab">{lang mms_v2ex:v2ex_110}</a><!--{/if}--><!--{if $v2ex['mms_blog'] == 1}--><!--{/if}--><!--{if $v2ex['mms_album'] == 1}--><!--{/if}--><!--{if $v2ex['mms_doing'] == 1}--><!--{/if}-->$v2ex['mms_indexdaohang']<!--{if $v2ex['mms_hot'] == 1}--><a href="forum.php?mod=guide&view=hot" class="tab">{lang mms_v2ex:v2ex_4}</a><!--{/if}--><a href="forum.php?mod=guide&view=new" class="tab">{lang mms_v2ex:v2ex_5}</a><!--{if $_G['uid']}--><a href="home.php?mod=space&do=thread&view=me" class="tab">{lang mms_v2ex:v2ex_6}</a><a href="plugin.php?id=mms_v2ex:myconcernlist" class="tab">{lang mms_v2ex:v2ex_7}</a><!--{/if}--><!--{if $_G['uid']}--><!--{loop $user_conts $user_cont}--><!--{if $user_cont['following'] > '10'}--><a href="home.php?mod=follow" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{else}--><a href="home.php?mod=follow&view=other" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{/if}--><!--{/loop}--><!--{/if}--><a href="group.php?mod=index" class="tab_current">{lang group}</a>
  </div>
    <div class="cell tbmmu" id="SecondaryTabs">
        <div class="fr">
                	<a href="group.php">{lang mms_v2ex:v2ex_187}</a>&nbsp; <li class="fa fa-caret-right gray"></li>
				<script language="javascript">
					function succeedhandle_attentiongroup(locationhref) {
						hideWindow('attentiongroup');
						location.href = locationhref;
					}
				</script>
        </div>
				<i$actives[groupthread]><a href="group.php?mod=my&view=groupthread" class="pjax">{lang mms_v2ex:v2ex_6}{lang group}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
        <i$actives[mythread]><a href="group.php?mod=my&view=mythread" class="pjax">{lang my_thread}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
				<i$actives[join]><a href="group.php?mod=my&view=join" class="pjax">{lang mms_v2ex:v2ex_188}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
				<i$actives[manager]><a href="group.php?mod=my&view=manager" class="pjax">{lang my_manage}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
				<i><a href="" onclick="showWindow('attentiongroup', 'group.php?mod=attentiongroup', 'get', 0);">[<i class="fa fa-heart" aria-hidden="true"></i>]{lang mms_v2ex:v2ex_189}</a></i>
    </div>
<!--{hook/my_header}--><!--{if $common_hot}-->
<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
<div class="mn">
		<!--{if $attentionthread}-->
			<!--{loop $attentionthread $groupid $threads}-->
<div class="cell">
<strong class="gray">［<i class="fa fa-heart" aria-hidden="true"></i>］</strong>{$usergroups['groups'][$groupid]}
<div class="fr">
<a href="forum.php?mod=group&fid=$groupid">{lang mms_v2ex:v2ex_190}</a>
</div>
</div>

						<!--{loop $threads $tid $thread}-->

    <div class="cell">

        <table cellpadding="0" cellspacing="0" border="0" width="100%">

            <tr>

                <td width="auto" valign="middle">

                    <span class="item_title">

								<!--{if $thread[folder] == 'lock'}-->

									<img src="{IMGDIR}/folder_lock.gif" /></a>

								<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

									<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" /></a>

								<!--{else}-->

<img src="{IMGDIR}/folder_$thread[folder].gif" /></a>

								<!--{/if}-->

            <a href="forum.php?mod=viewthread&tid=$tid" >$thread[subject]</a>

                    </span>

                <div class="sep5"></div>

                <span class="small fade">

                    <a href="forum.php?mod=group&fid=$groupid" class="node">{$usergroups['groups'][$groupid]}</a>



                    &nbsp;·&nbsp; $thread[lastpost]

                                    <!--{if $thread['replies']}-->

                &nbsp;·&nbsp; {lang mms_v2ex:v2ex_100} <strong><!--{if $thread['lastposter']}--><a href="home.php?mod=space&username=$thread[lastposter]">$thread[lastposter]</a><!--{else}-->{lang anonymous}<!--{/if}--></strong>

                <!--{else}-->



                <!--{/if}-->

                </span>

                </td>

                <td width="50" align="right" valign="middle">

                    <!--{if $thread['replies']}-->

                    <a href="forum.php?mod=viewthread&tid=$tid" class="count_livid">$thread[replies]</a>

                    <!--{else}-->

                    <!--{/if}-->

                </td>

            </tr>

        </table>

    </div>



						<!--{/loop}-->



			<!--{/loop}-->

		<!--{/if}-->




<div class="sep10"></div>
<div class="inner">
		<!--{if $view == 'groupthread' || $view == 'mythread'}-->

			<a href="group.php?mod=my&view=$view" id="ttp_all" class="pjax ttags{if $_GET[typeid]==$type[fid]}_current{/if}">{lang all}</a><!--{loop $usergroups['grouptype'] $type}--><a href="group.php?mod=my&view=$view{if $typeid != $type['fid']}&typeid=$type[fid]{/if}" class="pjax ttags{if $_GET[typeid]==$type[fid]}_current{/if}">$type[name]</a><!--{/loop}-->
</div>

<div style="display:none;"><!--{hook/my_side_top}--><!--{hook/my_side_bottom}--></div>

<div class="cell">

<!--{if $view == 'groupthread'}-->{lang last_topic_in_group}<!--{else}-->{lang mms_v2ex:v2ex_191}{lang group}{lang mms_v2ex:v2ex_192}<!--{/if}-->

<div class="fr">



</div>

</div>

				<!--{if $groupthreadlist}-->

					<!--{loop $groupthreadlist $tid $thread}-->

    <div class="cell">

        <table cellpadding="0" cellspacing="0" border="0" width="100%">

            <tr>

                <td width="auto" valign="middle">

                    <span class="item_title">

								<!--{if $thread[folder] == 'lock'}-->

									<img src="{IMGDIR}/folder_lock.gif" /></a>

								<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->

									<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" /></a>

								<!--{else}-->

<img src="{IMGDIR}/folder_$thread[folder].gif" /></a>

								<!--{/if}-->

            <a href="forum.php?mod=viewthread&tid=$tid" >$thread[subject]</a>

                    </span>

                <div class="sep5"></div>

                <span class="small fade">

                    <a href="forum.php?mod=group&fid=$thread[fid]"   class="node">$thread[groupname]</a>



                    &nbsp;·&nbsp; $thread[lastpost]

                                    <!--{if $thread['replies']}-->

                &nbsp;·&nbsp; {lang mms_v2ex:v2ex_100} <strong><!--{if $thread['lastposter']}--><a href="home.php?mod=space&username=$thread[lastposter]">$thread[lastposter]</a><!--{else}-->{lang anonymous}<!--{/if}--></strong>

                <!--{else}-->



                <!--{/if}-->

                </span>

                </td>

                <td width="50" align="right" valign="middle">

                    <!--{if $thread['replies']}-->

                    <a href="forum.php?mod=viewthread&tid=$tid" class="count_livid">$thread[replies]</a>

                    <!--{else}-->

                    <!--{/if}-->

                </td>

            </tr>

        </table>

    </div>

					<!--{/loop}-->

				<!--{else}-->

    <div class="cell">

        <table cellpadding="0" cellspacing="0" border="0" width="100%">

            <tr>

<div class="emp">{lang mms_v2ex:v2ex_193}</div>

            </tr>

        </table>

    </div>

				<!--{/if}-->



<div class="sep20"></div>





	<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->



	<!--{elseif $view == 'manager' || $view == 'join'}-->

		<!--{if $grouplist}-->

                  <div class="sep10"></div>

			<div class="member-list">

				<ul style="position:relative;text-align:left;">

					<!--{loop $grouplist $groupid $group}-->

					<li>

						<div class="avt pic "><a href="forum.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a></div>

						<div class="name"><!--{if $group['flevel'] == '-1'}-->({lang group_wait_mod})<!--{/if}--><a href="forum.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></div>

					</li>

					<!--{/loop}-->

				</ul>

			</div>

                 <div class="sep10"></div>

			<!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->

		<!--{else}-->

			<div class="emp"><!--{if $view == 'manager'}-->{lang mms_v2ex:v2ex_194}{lang group}，<a href="forum.php?mod=group&action=create">{lang mms_v2ex:v2ex_195}</a><!--{elseif $view == 'join'}-->{lang mms_v2ex:v2ex_196}{lang group}，<a href="group.php?mod=index">{lang mms_v2ex:v2ex_197}{lang group}</a>。<!--{/if}--></div>

		<!--{/if}-->

	<!--{/if}--><!--{/if}-->

	<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->

	<!--{hook/my_bottom}-->



	</div>







        </div></div> </div>

        <div class="c"></div>

        <div class="sep20"></div>

<!--{template common/footer}-->
