<?php exit;?>
<style>
.member-list ul {
  margin-top: -20px;
  letter-spacing: -0.31em;
  *letter-spacing: normal;
  word-spacing: -0.43em;
  font-size: 0;
}
.member-list .pic {
  margin-bottom: 5px;
}
.member-list li {
  display: inline-block;
  *display: inline;
  zoom: 1;
  width: 88px;
  margin-top: 20px;
  text-align: center;
  font-size: 12px;
  vertical-align: top;
  letter-spacing: normal;
  word-spacing: normal;
}
.member-list .name {
  clear: both;
}
.u_actions { display:inline-block;*display:inline;zoom:1;vertical-align:middle; }
</style>
<div class="cell" style="background-color: #f9f9f9; padding: 0px 0px 0px 0px;"></div>
<!--{if $op == 'alluser'}-->
	<!--{if $adminuserlist}-->
		<div class="box bml">
			<div class="inner">
				<strong class="gray">{lang group_admin_member}</strong>
<div class="sep10"></div>
<div class="member-list">
				<ul class="mls cl" style="position:relative;text-align:left;">
					<!--{loop $adminuserlist $user}-->
					<li>
						<div class="avt pic "><a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt" c="1">
						<!--{if $user['level'] == 1}-->
							<em class="gm"></em>
						<!--{elseif $user['level'] == 2}-->
							<em class="gm" style="filter:alpha(opacity=50); opacity: 0.5"></em>
						<!--{/if}-->
						<!--{if $user['online']}-->
							<em class="gol" style="margin-top: 15px;"></em>
						<!--{/if}-->
							<!--{echo avatar($user[uid], 'small')}-->
						</a></div>
						<div class="name"><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
            </div>
	<!--{/if}-->
	<!--{if $staruserlist || $alluserlist}-->
		<div class="box bml">
			<div class="inner">
				<strong class="gray">{lang group}{lang member}</strong>
<div class="sep10"></div>
<div class="member-list">
				<!--{if $staruserlist}-->
					<ul class="mls cl" style="position:relative;text-align:left;">
						<!--{loop $staruserlist $user}-->
						<li>
							<div class="avt pic "><a href="home.php?mod=space&uid=$user[uid]" title="{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}" class="avt" c="1">
							<em class="gs"></em>
							<!--{if $user['online']}-->
								<em class="gol"{if $user['level'] <= 3} style="margin-top: 15px;"{/if} title="{lang login_normal_mode}"></em>
							<!--{/if}-->
							<!--{echo avatar($user[uid], 'small')}-->
							</a></div>
							<div class="name"><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></div>
						</li>
						<!--{/loop}-->
					</ul>
				<!--{/if}-->
				<!--{if $alluserlist}-->
					<ul class="mls cl" style="position:relative;text-align:left;">
						<!--{loop $alluserlist $user}-->
						<li>
							<div class="avt pic "><a href="home.php?mod=space&uid=$user[uid]" class="avt" c="1"><!--{echo avatar($user[uid], 'small')}--></a></div>
							<div class="name"><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></div>
						</li>
						<!--{/loop}-->
					</ul>
				<!--{/if}-->
			</div>
		</div></div>
	<!--{/if}-->
	<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->
<!--{/if}-->
