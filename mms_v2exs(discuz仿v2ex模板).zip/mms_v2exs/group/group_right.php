<?php exit;?>
<!--{if $action == 'create'}-->
<!--{else}-->
<div class="sep20"></div>
<!--{/if}-->



<style>

.member-list ul {

  margin-top: -20px;

  letter-spacing: -0.31em;

  *letter-spacing: normal;

  word-spacing: -0.43em;

  font-size: 0;

}

.member-list .pic {

  margin-bottom: 5px;

}

.member-list li {

  display: inline-block;

  *display: inline;

  zoom: 1;

  width: 88px;

  margin-top: 20px;

  text-align: center;

  font-size: 12px;

  vertical-align: top;

  letter-spacing: normal;

  word-spacing: normal;

}

.member-list .name {

  clear: both;

}

.u_actions { display:inline-block;*display:inline;zoom:1;vertical-align:middle; }

</style>


<!--{if CURMODULE == 'group'}--><!--{hook/group_side_top}--><!--{else}--><!--{hook/forumdisplay_side_top}--><!--{/if}-->


<!--{if $action == 'index'}-->





<div class="box">

<div class="cell">

	<div class="bml tns">

		<table cellpadding="4" cellspacing="0" border="0">

			<tr>

				<th><p>$_G[forum][posts]</p>{lang posts}</th>

				<th><p>$_G[forum][membernum]</p>{lang member}</th>

				<td><p>$groupcache[ranking][data][today]</p>{lang group_member_rank}</td>

			</tr>

		</table>

	</div>

</div></div> <div class="sep20"></div>

	<!--{hook/group_index_side}-->

	<!--{if $status != 2 && $status != 3}-->

<div class="box">

<div class="cell">



			<strong class="gray">

				<i class="a" id="new" onmouseover="this.className='a';$('top').className='';$('newuserlist').style.display='block';$('topuserlist').style.display='none';"><a href="javascript:;">{lang group_member_new}</a></i>&nbsp;/&nbsp;<i id="top" onmouseover="this.className='a';$('new').className='';$('topuserlist').style.display='block';$('newuserlist').style.display='none';"><a href="javascript:;">{lang group_member_active}</a></i></strong>



</div>

<div class="sep10"></div>

			<div class="member-list">

				<ul id="newuserlist" style="display:block;position:relative;text-align:left;">

					<!--{loop $newuserlist $user}-->

						<li>

							<div class="avt pic "><a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{elseif $user['level'] == 3}{lang group_star_member_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" c="1">

								<!--{echo avatar($user[uid], 'small')}-->

							</a> </div>

							<div class="name">

								<a href="home.php?mod=space&uid=$user[uid]">$user[username]</a>

							</div>

						</li>

					<!--{/loop}-->

				</ul>

				<ul id="topuserlist" style="display:none;position:relative;text-align:left;">

					<!--{loop $activityuserlist $user}-->

						<li>

							<div class="avt pic "><a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{elseif $user['level'] == 3}{lang group_star_member_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" c="1">

								<!--{echo avatar($user[uid], 'small')}-->

							</a></div>

							<div class="name">

								<a href="home.php?mod=space&uid=$user[uid]">$user[username]</a>

							</div>

						</li>

					<!--{/loop}-->

				</ul>

                 <div class="sep10"></div>

			</div>



</div><div class="sep20"></div>

		<!--{if $groupviewed_list}-->

<div class="box">

			<div class="cell">

			<strong class="gray">{lang mms_v2ex:v2ex_198}{lang group}</strong>

			</div>

    <div class="sep10"></div>

			<div class="member-list">

				<ul style="position:relative;text-align:left;">

					<!--{loop $groupviewed_list $groupid $group}-->

					<li>

						<div class="avt pic "><a href="forum.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a></div>

						<div class="name" style="width:80px;white-space:nowrap;overflow:hidden;text-overflow : ellipsis;MARGIN-RIGHT: auto; MARGIN-LEFT: auto;"><a href="forum.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></div>
<span>($group[membernum])</span>
					</li>

					<!--{/loop}-->

				</ul>

			</div>

<div class="sep10"></div>

</div>   <div class="sep20"></div>

		<!--{/if}-->

	<!--{/if}-->

<!--{elseif $action == 'list'}-->

	<!--{if $groupcache['replies']['data']}-->
<div class="box">

    <div class="cell"><strong class="gray">{lang mms_v2ex:v2ex_199}</strong></div>



					<!--{loop $groupcache['replies']['data'] $tid $thread}-->
<div class="cell">
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td width="24" valign="middle" align="center">
                <a href="home.php?mod=space&uid=$thread[authorid]"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$thread[authorid]&size=small" class="avatar" border="0" align="default" style="max-width: 24px; max-height: 24px;" /></a>
            </td>
            <td width="10"></td>
            <td width="auto" valign="middle">
                <span class="item_hot_topic_title">
                <a href="forum.php?mod=viewthread&tid=$tid">$thread[subject]</a>
                </span>
            </td>
        </tr>
    </table>
</div>
					<!--{/loop}-->

</div>   <div class="sep20"></div>

	<!--{/if}-->

	<!--{if $groupcache['digest']['data']}-->

<div class="box">

    <div class="cell"><strong class="gray">{lang mms_v2ex:v2ex_200}</strong></div>

					<!--{loop $groupcache['digest']['data'] $tid $thread}-->

<div class="cell">
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td width="24" valign="middle" align="center">
                <a href="home.php?mod=space&uid=$thread[authorid]"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$thread[authorid]&size=small" class="avatar" border="0" align="default" style="max-width: 24px; max-height: 24px;" /></a>
            </td>
            <td width="10"></td>
            <td width="auto" valign="middle">
                <span class="item_hot_topic_title">
                <a href="forum.php?mod=viewthread&tid=$tid">$thread[subject]</a>
                </span>
            </td>
        </tr>
    </table>
</div>

					<!--{/loop}-->

</div>   <div class="sep20"></div>

	<!--{/if}-->

<!--{/if}-->





<!--{if $action == 'create'}-->

<!--{subtemplate common/1111}-->
<div class="sep20"></div>
	<div class="box bmn">

		<div class="bm_c xw1 xi1">{lang group_you_have}</div>

	</div>



<!--{else}-->

	<!--{if $action != 'index' && ($status != 2 || $status != 3)}-->

		<div class="box bml">
 <div class="cell"><strong class="gray">{lang mms_v2ex:v2ex_201}{lang group}{lang mms_v2ex:v2ex_202}</strong></div>
			<div class="inner">

<div class="sep10"></div>

		<div class="bm_c hm pns">

			<form method="post" action="search.php?mod=group&srchfid=$_G[fid]&searchsubmit=1">

				<input type="text" name="srchtxt" id="groupsearch" class="px p_fre vm" size="15" value="{lang input_search_key_words}" onclick="$('groupsearch').value=''" />&nbsp;

				<button type="submit" class="pn vm"><span>{lang search}</span></button>

			</form>

		</div>

	</div>

</div>   <div class="sep20"></div>

	<!--{/if}-->



<div class="box">

 <div class="cell">

<strong class="gray">{lang group}{lang mms_v2ex:v2ex_203}</strong>

</div>

<div class="inner">


			<p>

				<!--{if $_G['setting']['allowgroupdomain'] && !empty($_G['setting']['domain']['root']['group']) && !empty($_G['forum']['domain'])}-->

				<a href="https://{$_G[forum][domain]}.{$_G['setting']['domain']['root']['group']}" id="group_link"></a>

				<!--{else}-->

				<a href="forum.php?mod=group&fid={$_G[fid]}" id="group_link"></a>

				<!--{/if}-->

				[<a href="javascript:;" onclick="setCopy($('group_link').href, '{lang group_url_copy_finished}')" class="xi2">{lang copy}</a>]

			</p>

			<script type="text/javascript">$('group_link').innerHTML = $('group_link').href</script>

			<p class="ptn xg1">$_G[forum][foundername] {lang create_on} $_G[forum][dateline]</p>

			<!--{if $status == 'isgroupuser'}--><p class="ptn"><a onclick="showDialog('{lang group_exit_confirm}', 'confirm', '', function(){location.href='forum.php?mod=group&action=out&fid=$_G[fid]'})" href="javascript:;" class="xi2">{lang group_exit}</a><p><!--{/if}-->


</div>

</div>

<!--{/if}-->
