<?php exit;?>
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<div id="SecondaryTabs" class="cell">

		<div class="fr">

<a href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})" onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')" title="{lang send_posts}">{lang mms_v2ex:v2ex_173}</a>&nbsp;&nbsp;<li class="fa fa-caret-right gray"></li>

		</div>

		<i id="ttp_all"{if !$_GET['typeid']} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></i>

<!--{if $_G['forum']['threadtypes']}-->
		<!--{if $_G['forum']['threadtypes']}-->
			<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
				&nbsp;&nbsp;&nbsp;&nbsp;<i{if $_GET['typeid'] == $id} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a></i>
			<!--{/loop}-->
		<!--{/if}-->
		<!--{hook/forumdisplay_filter_extra}-->
<!--{/if}-->
</div>

<div style="display:none;"><!--{hook/forumdisplay_postbutton_top}--></div>

<div id="threadlist" style="position: relative;">

		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">

			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<input type="hidden" name="listextra" value="$extra" />



<!--{if $_G['forum_threadcount']}-->

<!--{loop $_G['forum_threadlist'] $key $thread}-->

<!--{ad/threadlist}-->

    <div class="cell">

        <table cellpadding="0" cellspacing="0" border="0" width="100%">

            <tr>

            <td width="48" valign="top" align="center">



<!--{if $thread['authorid'] && $thread['author']}-->

											<a href="home.php?mod=space&uid=$thread[authorid]" c="1" ><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$thread[authorid]&size=small" class="avatar" border="0" align="default" style="max-width: 48px; max-height: 48px;" /></a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->

										<!--{else}-->

<img src="$_G['setting'][ucenterurl]/avatar.php?uid=4&size=small" class="avatar" border="0" align="default" style="max-width: 48px; max-height: 48px;" />

										<!--{/if}-->

            </td>

                <td width="10"></td>

                <td width="auto" valign="middle">

                    <span class="item_title">





									<!--{if $thread[folder] == 'lock'}-->
										<img src="{IMGDIR}/folder_lock.gif" />
									<!--{elseif $thread['special'] == 1}-->
										<img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
									<!--{elseif $thread['special'] == 2}-->
										<img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
									<!--{elseif $thread['special'] == 3}-->
										<img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
									<!--{elseif $thread['special'] == 4}-->
										<img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
									<!--{elseif $thread['special'] == 5}-->
										<img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" />
									<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
										<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
									<!--{else}-->

									<!--{/if}-->

								<!--{if $_G['forum']['ismoderator']}-->

									<!--{if $thread['fid'] == $_G[fid]}-->
										<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
											<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" class="pc" value="$thread[tid]" />
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
									<!--{else}-->
										<input type="checkbox" disabled="disabled" />
									<!--{/if}-->

								<!--{/if}-->







									<!--{hook/forumdisplay_thread $key}-->
									<!--{if $thread['moved']}-->
										<!--{if $_G['forum']['ismoderator']}-->
											<a href="forum.php?mod=topicadmin&action=moderate&optgroup=3&operation=delete&tid=$thread[moved]" onclick="showWindow('mods', this.href);return false">{lang thread_moved}:</a>
										<!--{else}-->
											{lang thread_moved}:
										<!--{/if}-->
									<!--{/if}-->
									<span class="small">$thread[typehtml]</span>
									<span id="thread_$thread[tid]"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"$thread[highlight] class="xst">$thread[subject]</a></span>
									<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
									<!--{if $thread['price'] > 0}-->
										<!--{if $thread['special'] == '3'}-->
										- <span style="color: #C60">[{lang thread_reward}<span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span>
										<!--{else}-->
										- [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
										<!--{/if}-->
									<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
										- <span style="color: #269F11">[{lang reward_solved}]</span>
									<!--{/if}-->
									<!--{if $thread['attachment'] == 2}-->
										<img src="{STATICURL}image/filetype/image_s.gif" alt="{lang attach_img}" align="absmiddle" />
									<!--{elseif $thread['attachment'] == 1}-->
										<img src="{STATICURL}image/filetype/common.gif" alt="{lang attachment}" align="absmiddle" />
									<!--{/if}-->
									<!--{if $thread['displayorder'] == 0}-->
										<!--{if $thread[recommendicon]}-->
											<img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
										<!--{/if}-->
										<!--{if $thread[heatlevel]}-->
											<img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="$thread[heatlevel] {lang heats}" />
										<!--{/if}-->
										<!--{if $thread['digest'] > 0}-->
											<img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
										<!--{/if}-->
										<!--{if $thread['rate'] > 0}-->
											<img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
										<!--{/if}-->
									<!--{/if}-->
									<!--{if $thread[multipage]}-->
										<span class="tps">$thread[multipage]</span>
									<!--{/if}-->
								</th>




                    </span>

                <div class="sep5"></div>

                <span class="small fade">

                    <strong>

									<!--{if $thread['authorid'] && $thread['author']}-->

										<a href="home.php?mod=space&uid=$thread[authorid]">$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}-->$verify[$thread[authorid]]<!--{/if}-->

									<!--{else}-->

										<!--{if $_G['forum']['ismoderator']}-->

											<a href="home.php?mod=space&uid=$thread[authorid]">{lang anonymous}</a>

										<!--{else}-->

											{lang anonymous}

										<!--{/if}-->

									<!--{/if}-->

                    </strong> &nbsp;·&nbsp;



$thread[lastpost]





                <!--{if $thread['replies']}-->

                &nbsp;·&nbsp; {lang mms_v2ex:v2ex_100} <strong><!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1" >$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></strong>

                <!--{else}-->



                <!--{/if}-->





                    </span>

                </td>

    <td align="right" valign="middle">

                    <!--{if $thread['allreplies']}-->

                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="count_livid">$thread[allreplies]</a>

                    <!--{else}-->

                    <!--{/if}-->

    </td>

            </tr>

        </table>

    </div>

<!--{/loop}-->

<!--{else}-->

    <div class="cell" id="threadlist" style="position: relative;">

        <table cellpadding="0" cellspacing="0" border="0" width="100%">

            <tr>

{lang mms_v2ex:v2ex_175}{lang mms_v2ex:v2ex_group}{lang mms_v2ex:v2ex_176}

            </tr>

        </table>

    </div>

<!--{/if}-->











			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->

				<!--{template forum/topicadmin_modlayer}-->

			<!--{/if}-->

		</form>

</div>














<!--{hook/forumdisplay_postbutton_bottom}-->




<!--{if $status == 'isgroupuser' && helper_access::check_module('group')}-->
 $multipage
<!--{else}-->
<div class="inner">
<span class="chevron">→</span> <a href="forum.php?mod=group&action=join&fid=$_G[fid]">{lang mms_v2ex:v2ex_169}{lang mms_v2ex:v2ex_group}{lang mms_v2ex:v2ex_179}</a>
</div>
<!--{/if}-->








<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->

	<ul class="p_pop" id="newspecial_menu" style="display: none">

		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" onclick="showWindow('newthread', this.href);doane(event)">{lang post_newthread}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->

		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->

		<!--{if $_G['setting']['threadplugins']}-->

			<!--{loop $_G['forum']['threadplugin'] $tpid}-->

				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->

					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url($_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>

				<!--{/if}-->

			<!--{/loop}-->

		<!--{/if}-->

	</ul>

<!--{/if}-->
