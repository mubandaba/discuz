<?php exit;?>
<!--{template common/header}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<!--{if $v2ex['pjax'] == 1}-->
<script>
pjax_init();
function pjax_init(){
    document.addEventListener('pjax:send', function() {
        NProgress.start();
    });
    document.addEventListener('pjax:complete', function() {
        NProgress.done();
    });
    document.addEventListener('pjax:error', function() {
    });
    document.addEventListener('pjax:success', function() {
    });
    document.addEventListener('DOMContentLoaded', function() {
        var pjax = new Pjax({
            elements: 'a.pjax',
            selectors: [
                'title',
                '#Main'
            ]
        });
    });
}
</script>
<!--{/if}-->
<!--{if $common_hot}-->
<div id="Wrapper">
        <div class="content">
            <div id="Leftbar"></div>
<!--{subtemplate forum/adv_custom}-->
<div id="Main">
<div class="sep20"></div>
<div id="ct" class="box">

  <div class="inner" id="Tabs">
<!--{if $v2ex['mms_digest'] == 1}--><a href="forum.php?mod=guide&view=digest" class="tab">{lang mms_v2ex:v2ex_1}</a><!--{/if}--><!--{if $v2ex['mms_newthread'] == 1}--><a href="forum.php?mod=guide&view=newthread" class="tab">{lang mms_v2ex:v2ex_2}</a><!--{/if}--><!--{if $v2ex['mms_sofa'] == 1}--><a href="forum.php?mod=guide&view=sofa" class="tab">{lang mms_v2ex:v2ex_3}</a><!--{/if}--><!--{if $v2ex['mms_share'] == 1}--><a href="home.php?mod=space&do=share&view=all" class="tab">{lang mms_v2ex:v2ex_110}</a><!--{/if}--><!--{if $v2ex['mms_blog'] == 1}--><!--{/if}--><!--{if $v2ex['mms_album'] == 1}--><!--{/if}--><!--{if $v2ex['mms_doing'] == 1}--><!--{/if}-->$v2ex['mms_indexdaohang']<!--{if $v2ex['mms_hot'] == 1}--><a href="forum.php?mod=guide&view=hot" class="tab">{lang mms_v2ex:v2ex_4}</a><!--{/if}--><a href="forum.php?mod=guide&view=new" class="tab">{lang mms_v2ex:v2ex_5}</a><!--{if $_G['uid']}--><a href="home.php?mod=space&do=thread&view=me" class="tab">{lang mms_v2ex:v2ex_6}</a><a href="plugin.php?id=mms_v2ex:myconcernlist" class="tab">{lang mms_v2ex:v2ex_7}</a><!--{/if}--><!--{if $_G['uid']}--><!--{loop $user_conts $user_cont}--><!--{if $user_cont['following'] > '10'}--><a href="home.php?mod=follow" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{else}--><a href="home.php?mod=follow&view=other" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{/if}--><!--{/loop}--><!--{/if}--><a href="group.php?mod=index" class="tab_current">{lang group}</a>
  </div>
            <div class="cell tbmmu" id="SecondaryTabs">
            	<div class="fr">
            		<a href="group.php?mod=my">{lang my_group}</a>&nbsp; <li class="fa fa-caret-right gray"></li>
            	</div>
            	  <i><a href="group.php">{lang mms_v2ex:groupjingxuan}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
            	<!--{loop $first $groupid $group}-->
            		<i{if $_GET[gid]==$groupid} class="a"{/if}><a href="group.php?gid=$groupid" class="pjax">$group[name]</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
            	<!--{/loop}-->
            </div>
<div class="cell">
  <table cellpadding="0" cellspacing="0" border="0">
    <tr>
      <td align="right" width="60"><span style="font-size: 16px;"><b>$curtype[name]</b></span>&nbsp;&nbsp;</td>
      <td style="line-height: 200%; padding-left: 10px;">
        <!--{if $typelist}-->
        <!--{loop $typelist $fid $type}-->
        <span class="xg1" style="font-size: 12px;">$type[name]&nbsp;</span>
        <!--{/loop}-->
        <!--{else}-->
        <a href="group.php?sgid=$fid" style="font-size: 12px;">$type[name]</a> &nbsp;
        <!--{/if}-->
       </td>
     </tr>
   </table>
</div>





<!--{ad/text/wp a_t}-->

<style id="diy_style" type="text/css"></style>

<div>

	<div class="mn">

		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->

		<div class="inner" style="font-size: 12px;">



			<!--{hook/index_top}-->

			<!--{if $list}-->

				<div class="tbmu cl bw0">

					<span class="y">

					<select title="{lang orderby}" onchange="location.href=this.value" class="ps">

						<option value="$url" $selectorder[default]>{lang orderby_default}</option>

						<option value="$url&orderby=thread" $selectorder[thread]>{lang stats_main_threads_count}</option>

						<option value="$url&orderby=membernum" $selectorder[membernum]>{lang group_member_count}</option>

						<option value="$url&orderby=dateline" $selectorder[dateline]>{lang group_create_time}</option>

						<option value="$url&orderby=activity" $selectorder[activity]>{lang group_activities}</option>

					</select>

					</span>

					<span class="xg1">{lang group_total_numbers}</span>

				</div>

				<!--{if $curtype['forumcolumns'] > 1}-->

					<div class="bm_c">

						<table cellspacing="0" cellpadding="0" class="fl_tb">

							<tr class="fl_row">

								<!--{loop $list $fid $val}-->

								<!--{if $val['orderid'] && ($val['orderid'] % $curtype['forumcolumns'] == 0)}-->

							</tr>

							<tr class="fl_row">

								<!--{/if}-->

								<td class="fl_g" style="width: $curtype[forumcolwidth]">

									<div class="fl_icn_g"><a href="forum.php?mod=group&fid=$fid" title="$val[name]"><img width="48" height="48" src="$val[icon]" alt="$val[name]" /></a></div>

									<dl>

										<dt><a href="forum.php?mod=group&fid=$fid" title="$val[name]">$val[name]</a></dt>

										<dd>{lang group_total_members_threads}</dd>

										<dd><a href=""><a href="forum.php?mod=group&fid=$fid">{lang group_founded_in}: $val[dateline]</a></dd>

									</dl>

								</td>

								<!--{/loop}-->

								$endrows

							</tr>

						</table>

					</div>

				<!--{else}-->

					<div class="bm_c">

						<table cellspacing="0" cellpadding="0" class="fl_tb">

						<!--{loop $list $fid $val}-->

							<tr class="fl_row">

								<td class="fl_icn"><a href="forum.php?mod=group&fid=$fid" title="$val[name]"><img width="48" height="48" src="$val[icon]" alt="$val[name]" /></a></td>

								<td>

									<!--{hook/index_grouplist $fid}-->

									<strong><a href="forum.php?mod=group&fid=$fid" title="$val[name]">$val[name]</a></strong>

									<p class="xg1">$val[description]</p>

								</td>

								<td class="fl_i">

									<span class="i_z z"><strong>$val[membernum]</strong><em class="xg1">{lang group_member}</em></span>

									<span class="i_y z"><strong>$val[threads]</strong><em class="xg1">{lang threads}</em></span>

								</td>

							</tr>

						<!--{/loop}-->

						</table>

					</div>

				<!--{/if}-->

				<!--{hook/index_bottom}-->

			<!--{else}-->

				<div style="text-align:center;">
          <br>
					<h2>{lang group_category_no_groups}</h2>
          <br>
					<p>{lang group_category_no_groups_detail}</p>
				</div>

			<!--{/if}-->

		</div>


		<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->

	</div>

	<div class="sd">

		<!--[diy=diysidetop]--><div id="diysidetop" class="area"></div><!--[/diy]-->

		<!--{hook/index_side_top}-->


		<!--[diy=diytopgrouptop]--><div id="diytopgrouptop" class="area"></div><!--[/diy]-->


		<div class="drag">

			<!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->

		</div>

		<!--{hook/index_side_bottom}-->

	</div>

</div>



<div class="wp mtn">

	<!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->

</div>

<!--{/if}-->
</div></div></div>
<div class="c"></div>
<div class="sep20"></div>
<!--{template common/footer}-->
