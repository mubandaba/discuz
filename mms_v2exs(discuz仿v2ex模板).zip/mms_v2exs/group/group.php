<?php exit;?>
<!--{template common/header}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->


	<!--{ad/text/wp a_t}-->



    <div id="Wrapper">

        <div class="content">



            <div id="Leftbar"></div>

            <div id="Rightbar">








			<!--{subtemplate group/group_right}-->

			<!--{if $v2ex['sys_ag'] == 1}--><!--{if CURMODULE == 'group'}--><!--{hook/group_side_bottom}--><!--{else}--><!--{hook/forumdisplay_side_bottom}--><!--{/if}-->




            </div>

            <div id="Main">

                <div class="sep20"></div>



<div class="box" style="min-height:100px; height:auto!important; height:100px;">
  <!--{if $action == 'create'}-->
  <div class="headers"><a href="group.php?mod=my">$_G['setting'][bbname]</a> <span class="chevron">&nbsp;&nbsp;<i class="fa fa-angle-right fa-1"></i>&nbsp;&nbsp;</span> {lang mms_v2ex:v2ex_136}{lang group}<!--{if $_G['setting']['groupmod']}-->&nbsp;&nbsp;&nbsp;({lang group_create_mod})<!--{/if}-->
  </div>
  <!--{/if}-->
<div class="inner">

	<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->

			<!--{if $action != 'create'}-->




				<!--{if $_G['forum']['banner']}-->

<style type="text/css">
body { background-color: #efefef; background-image: url($_G[forum][banner]); background-repeat: no-repeat; background-attachment: fixed; background-position: center 0; background-size: cover; }
#Wrapper{ background-color: transparent; animation-delay: 2s; -webkit-animation-delay: 2s; animation: fadein 5s; -webkit-animation: fadein 5s; }
@-webkit-keyframes fadein { from { background-color: rgba(239, 239, 239, 255); } to { background-color: rgba(239, 239, 239, 0); } }
@keyframes fadein { from { background-color: rgba(239, 239, 239, 255); } to { background-color: rgba(239, 239, 239, 0); } }
#Main, #Top, #Bottom, #Rightbar { opacity: 0.95; }
</style>



<div id="group-info" style="margin: 0px 0px 20px; padding: 0px; height: 48px; line-height: 48px;">

	<img align="left" valign="top" class="pil groupicon" src="$_G[forum][icon]" alt="$_G[forum][name]" style="border: 0px; height: 48px; width: 48px; padding-right: 10px;" />

	<h1 style="margin: 0px; padding: 0px; font-size: 25px; word-wrap: break-word; display: inline; line-height: 1.1; vertical-align: middle;">

		$_G[forum][name]&nbsp;

	</h1>

	&nbsp; &nbsp;&nbsp;

	<div class="group-misc" style="margin: 0px; padding: 0px; display: inline-block; position: relative;">

        					<!--{if $status != 2 && $status != 3 && $status != 5}-->

								<!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->

								<div class="ptm pbm">

									<a type="button" class="j a_show_request_join_form bn-join-group" style="text-decoration: none; cursor: pointer; display: inline-block; zoom: 1; padding: 6px 10px; line-height: 1.2; border-top-left-radius: 3px; border-top-right-radius: 3px; border-bottom-right-radius: 3px; border-bottom-left-radius: 3px; color: rgb(255, 255, 255); background-color: rgb(110, 191, 195);" onclick="location.href='forum.php?mod=group&action=join&fid=$_G[fid]'"><em>{lang mms_v2ex:v2ex_204}{lang group}</em></a>

								</div>

								<!--{/if}-->

								<!--{if CURMODULE == 'group'}--><!--{hook/group_navlink}--><!--{else}--><!--{hook/forumdisplay_navlink}--><!--{/if}-->

							<!--{/if}-->



								<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->

								<bbb class="xi1">

									<!--{if $status == 3 || $status == 5}-->

										{lang group_has_joined}

									<!--{elseif helper_access::check_module('group')}-->

										<button type="button" class="pn" onclick="location.href='forum.php?mod=group&action=join&fid=$_G[fid]'"><em>{lang group_join_group}</em></button>

									<!--{/if}-->

								</bbb>

								<!--{/if}-->



		<!--{if $status == 'isgroupuser'}-->{lang mms_v2ex:v2ex_205}{lang group}{lang mms_v2ex:v2ex_206} &gt;&nbsp;<a onclick="showDialog('{lang group_exit_confirm}', 'confirm', '', function(){location.href='forum.php?mod=group&action=out&fid=$_G[fid]'})" href="javascript:;" class="xi2">{lang mms_v2ex:v2ex_207}{lang group}</a><!--{/if}-->

	</div>

</div>

<div class="grid-16-8 clearfix" style="margin: 0px; padding: 0px; zoom: 1; color: rgb(17, 17, 17); font-family: Helvetica, Arial, sans-serif; line-height: 19.440000534057617px; background-color: rgb(255, 255, 255);">

	<div class="article" >

		<div class="group-board" style="margin: 0px; padding: 10px 20px; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; position: relative; background: rgb(255, 244, 232);">

			<p>

				{lang mms_v2ex:v2ex_209}$_G[forum][dateline] &nbsp; &nbsp; {lang mms_v2ex:v2ex_208}：<!--{eval $i = 1;}--><!--{loop $groupmanagers $manage}--><!--{if $i <= 0}-->, <!--{/if}--><!--{eval $i--;}--><a href="home.php?mod=space&uid=$manage[uid]" >$manage[username]</a> <!--{/loop}-->

			</p>

			<div class="group-intro" style="margin: 0px; padding: 0px; color: rgb(34, 34, 34); word-wrap: break-word;">

<!--{if $_G['forum']['description']}--><br/>$_G[forum][description]<!--{else}--><!--{/if}-->

			</div>

<br/>



    <div class="fr">

<span class="y"><a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang favorite}" class="fa_fav">{lang favorite}</a><span class="pipe">|</span><!--{if $_G[setting][rssstatus] && !$_GET['archiveid']}--><a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" title="RSS" class="fa_rss">RSS</a><!--{/if}--><!--{if $status == 'isgroupuser' && helper_access::check_module('group')}--><span class="pipe">|</span><a href="javascript:;" onclick="showWindow('invite','misc.php?mod=invite&action=group&id=$_G[fid]')" class="fa_ivt"><strong class="xi2">{lang my_buddylist_invite}</strong></a><!--{/if}--></span>



    </div>

<!--{if $_G['current_grouplevel']['icon']}--><img src="$_G[current_grouplevel][icon]" title="{lang group_level}: $_G[current_grouplevel][leveltitle]" class="vm"><!--{/if}-->{lang credits}: $_G[forum][commoncredits] &nbsp;

<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->

            <bbb class="xi1">

									{lang group_join_type}:

									<!--{if $_G['forum']['jointype'] == 1}-->

										<strong>{lang group_join_type_invite}</strong>

									<!--{elseif $_G['forum']['jointype'] == 2}-->

										<strong>{lang group_join_type_moderate}</strong>

									<!--{else}-->

										<strong>{lang group_join_type_free}</strong>

									<!--{/if}-->

									{lang group_perm_visit}: <strong><!--{if $_G['forum']['gviewperm'] == 0}-->{lang group_perm_member_only}<!--{else}-->{lang group_perm_all_user}<!--{/if}--></strong></bbb>

<!--{/if}-->







		</div>



	</div>

</div>









				<!--{else}-->











<div id="group-info" style="margin: 0px 0px 20px; padding: 0px; height: 48px; line-height: 48px; ">

	<img align="left" valign="top" class="pil groupicon" src="$_G[forum][icon]" alt="$_G[forum][name]" style="border: 0px; height: 48px; width: 48px; padding-right: 10px;" />

	<h1 style="margin: 0px; padding: 0px; font-size: 25px; word-wrap: break-word; display: inline; line-height: 1.1; vertical-align: middle;">

		$_G[forum][name]&nbsp;

	</h1>

	&nbsp; &nbsp;&nbsp;

	<div class="group-misc" style="margin: 0px; padding: 0px; display: inline-block; position: relative;">

        					<!--{if $status != 2 && $status != 3 && $status != 5}-->

								<!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->

								<div class="ptm pbm">

									<a type="button" class="j a_show_request_join_form bn-join-group" style="text-decoration: none; cursor: pointer; display: inline-block; zoom: 1; padding: 6px 10px; line-height: 1.2; border-top-left-radius: 3px; border-top-right-radius: 3px; border-bottom-right-radius: 3px; border-bottom-left-radius: 3px; color: rgb(255, 255, 255); background-color: rgb(110, 191, 195);" onclick="location.href='forum.php?mod=group&action=join&fid=$_G[fid]'"><em>{lang mms_v2ex:v2ex_204}{lang group}</em></a>

								</div>

								<!--{/if}-->

								<!--{if CURMODULE == 'group'}--><!--{hook/group_navlink}--><!--{else}--><!--{hook/forumdisplay_navlink}--><!--{/if}-->

							<!--{/if}-->



								<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->

								<bbb class="xi1">

									<!--{if $status == 3 || $status == 5}-->

										{lang group_has_joined}

									<!--{elseif helper_access::check_module('group')}-->

										<button type="button" class="pn" onclick="location.href='forum.php?mod=group&action=join&fid=$_G[fid]'"><em>{lang group_join_group}</em></button>

									<!--{/if}-->

								</bbb>

								<!--{/if}-->



		<!--{if $status == 'isgroupuser'}-->{lang mms_v2ex:v2ex_205}{lang group}{lang mms_v2ex:v2ex_206} &gt;&nbsp;<a onclick="showDialog('{lang group_exit_confirm}', 'confirm', '', function(){location.href='forum.php?mod=group&action=out&fid=$_G[fid]'})" href="javascript:;" class="xi2">{lang mms_v2ex:v2ex_207}{lang group}</a><!--{/if}-->

	</div>

</div>

<div class="grid-16-8 clearfix" style="margin: 0px; padding: 0px; zoom: 1; color: rgb(17, 17, 17); font-family: Helvetica, Arial, sans-serif; line-height: 19.440000534057617px; background-color: rgb(255, 255, 255);">

	<div class="article">

		<div class="group-board" style="margin: 0px; padding: 10px 20px; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; position: relative; background: rgb(255, 244, 232);">

			<p>

				{lang mms_v2ex:v2ex_209}$_G[forum][dateline] &nbsp; &nbsp; {lang mms_v2ex:v2ex_208}：<!--{eval $i = 1;}--><!--{loop $groupmanagers $manage}--><!--{if $i <= 0}-->, <!--{/if}--><!--{eval $i--;}--><a href="home.php?mod=space&uid=$manage[uid]" >$manage[username]</a> <!--{/loop}-->

			</p>

			<div class="group-intro" style="margin: 0px; padding: 0px; color: rgb(34, 34, 34); word-wrap: break-word;">

<!--{if $_G['forum']['description']}--><br/>$_G[forum][description]<!--{else}--><!--{/if}-->

			</div>

<br/>



    <div class="fr">



<span class="y"><a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang favorite}" class="fa_fav">{lang favorite}</a><span class="pipe">|</span><!--{if $_G[setting][rssstatus] && !$_GET['archiveid']}--><a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" title="RSS" class="fa_rss">RSS</a><!--{/if}--><!--{if $status == 'isgroupuser' && helper_access::check_module('group')}--><span class="pipe">|</span><a href="javascript:;" onclick="showWindow('invite','misc.php?mod=invite&action=group&id=$_G[fid]')" class="fa_ivt"><strong class="xi2">{lang my_buddylist_invite}</strong></a><!--{/if}--></span>



    </div>

<!--{if $_G['current_grouplevel']['icon']}--><img src="$_G[current_grouplevel][icon]" title="{lang group_level}: $_G[current_grouplevel][leveltitle]" class="vm"><!--{/if}-->{lang credits}: $_G[forum][commoncredits] &nbsp;

<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->

            <bbb class="xi1">

									{lang group_join_type}:

									<!--{if $_G['forum']['jointype'] == 1}-->

										<strong>{lang group_join_type_invite}</strong>

									<!--{elseif $_G['forum']['jointype'] == 2}-->

										<strong>{lang group_join_type_moderate}</strong>

									<!--{else}-->

										<strong>{lang group_join_type_free}</strong>

									<!--{/if}-->

									{lang group_perm_visit}: <strong><!--{if $_G['forum']['gviewperm'] == 0}-->{lang group_perm_member_only}<!--{else}-->{lang group_perm_all_user}<!--{/if}--></strong></bbb>

<!--{/if}-->







		</div>



	</div>

</div>



				<!--{/if}-->


				<!--{if CURMODULE == 'group'}--><!--{hook/group_top}--><!--{else}--><!--{hook/forumdisplay_top}--><!--{/if}-->




        </div></div>





 <div class="sep20"></div>
<div class="box">

				<!--{if $status != 2 && $status != 3}-->


<div class="inner" id="Tabs">

						<a href="forum.php?mod=group&fid=$_G[fid]" title="" {if $action == 'index'}class="tab_current"{else}class="tab"{/if}>{lang home}</a>

						<a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" title="" {if $action == 'list'}class="tab_current"{else}class="tab"{/if}>{lang group_discuss_area}</a>

						<a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]" title="" {if $action == 'memberlist' || $action == 'invite'}class="tab_current"{else}class="tab"{/if}>{lang group}成员</a>

						<!--{if $_G['forum']['ismoderator']}--><a href="forum.php?mod=group&action=manage&fid=$_G[fid]" {if $action == 'manage'}class="tab_current"{else}class="tab"{/if}>{lang mms_v2ex:v2ex_161}{lang group}</a><!--{/if}-->

						<!--{if CURMODULE == 'group'}--><!--{hook/group_nav_extra}--><!--{else}--><!--{hook/forumdisplay_nav_extra}--><!--{/if}-->

  <!--{if in_array($_G['adminid'], array(1,2))}--><span class="a bw0_all y xi2"><a href="javascript:;" onclick="showWindow('grecommend$_G[fid]', 'forum.php?mod=group&action=recommend&fid=$_G[fid]');return false;">{lang group_push_to_forum}</a></span><!--{/if}-->
</div>







				<!--{/if}-->

			<!--{/if}-->

			<!--{if $action == 'index' && $status != 2 && $status != 3}-->

				<!--{subtemplate group/group_index}-->

			<!--{elseif $action == 'list'}-->

				<!--{subtemplate group/group_list}-->

			<!--{elseif $action == 'memberlist'}-->

				<!--{subtemplate group/group_memberlist}-->

			<!--{elseif $action == 'create'}-->

				<!--{subtemplate group/group_create}-->

			<!--{elseif $action == 'invite'}-->

				<!--{subtemplate group/group_invite}-->

			<!--{elseif $action == 'manage'}-->

				<!--{subtemplate group/group_manage}-->

			<!--{/if}-->

			<!--{if CURMODULE == 'group'}--><!--{hook/group_bottom}--><!--{else}--><!--{hook/forumdisplay_bottom}--><!--{/if}-->

			<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->


</div>



<!--{if $action == 'index' && $status != 2 && $status != 3}-->





<!--{elseif $action == 'list'}-->
<div class="sep20"></div>
<div class="box">
<!--{if $status == 'isgroupuser' && helper_access::check_module('group')}-->
<!--{else}-->      <div class="cell"><div class="fr"><a href="javascript:scroll(0,0)"><strong>↑</strong> 回到顶部</a></div>
        发布新主题
    </div>  <!--{/if}-->
    <div class="cell">

<!--{if $status == 'isgroupuser' && helper_access::check_module('group')}-->
	<!--{template forum/forumdisplay_fastpost}-->
<!--{else}-->
只有{lang mms_v2ex:v2ex_group}成员才能发布新主题
     <!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
&nbsp;<a href="forum.php?mod=group&action=join&fid=$_G[fid]"><em>> 加入这个{lang mms_v2ex:v2ex_group}</em></a>
     <!--{/if}-->
<!--{/if}-->

    </div>

</div>
<!--{/if}--><!--{/if}-->



            </div></div>
        <div class="c"></div>

        <div class="sep20"></div>





<!--{template common/footer}-->
