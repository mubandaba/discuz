<?php exit;?>
<div class="bm" id="main_messaqge">

	<form method="post" autocomplete="off" name="groupform" id="groupform" class="s_clear" action="forum.php?mod=group&action=invite">

		<input type="hidden" name="formhash" value="{FORMHASH}" />

		<input type="hidden" name="fid" value="$_G[fid]" />

		<input type="hidden" name="referer" value="{echo dreferer()}" />

		<!--{loop $friendarray $uid $member}-->

			<input type="checkbox" name="inviteuid[]" value="$uid">$member[username] $member[avatar]

		<!--{/loop}-->

		<table cellspacing="0" cellpadding="0" class="tfm" summary="{lang group_join_type_invite}">

			<caption>{lang group_choose_friend_to_invite}</caption>

			<tbody>

				<tr>

					<th>{lang group_invite_list}</th>

					<td><textarea rows="4" cols="40" name="invitemsg" class="pt"></textarea></td>

				</tr>

				<tr>

					<th>&nbsp;</th>

					<td><button class="pn pnc" type="submit" name="invitesubmit" value="true" tabindex="1"><strong>{lang finished}</strong></button></td>

				</tr>

			</tbody>

		</table>

	</form>

</div>