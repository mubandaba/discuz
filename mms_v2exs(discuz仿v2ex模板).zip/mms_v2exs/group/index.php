<?php exit;?>
<!--{template common/header}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<style type="text/css">
	.xl2 { background: url({IMGDIR}/vline.png) repeat-y 50% 0; }
		.xl2 li { width: 49.9%; }
			.xl2 li em { padding-right: 10px; }
				.xl2 .xl2_r em { padding-right: 0; }
			.xl2 .xl2_r i { padding-left: 10px; }

			a.xw1:link, a.tab_current:visited, a.tab_current:active {
			    display: inline-block;
			    font-size: 13px;
			    line-height: 13px;
			    padding: 5px 8px 5px 8px;
			    margin-right: 5px;
			    border-radius: 3px;
			    background-color: #334;
			    color: #fff;
			}

			a.xw1:hover {
			    background-color: #445;
			    color: #fff;
			    text-decoration: none;
			}
</style>
<div id="Wrapper">
        <div class="content">
            <div id="Leftbar"></div>
<!--{subtemplate forum/adv_custom}-->
<div id="Main">
<div class="sep20"></div>
<div id="ct" class="box">

<div class="inner" id="Tabs">
<!--{if $v2ex['mms_digest'] == 1}--><a href="forum.php?mod=guide&view=digest" class="tab">{lang mms_v2ex:v2ex_1}</a><!--{/if}--><!--{if $v2ex['mms_newthread'] == 1}--><a href="forum.php?mod=guide&view=newthread" class="tab">{lang mms_v2ex:v2ex_2}</a><!--{/if}--><!--{if $v2ex['mms_sofa'] == 1}--><a href="forum.php?mod=guide&view=sofa" class="tab">{lang mms_v2ex:v2ex_3}</a><!--{/if}--><!--{if $v2ex['mms_share'] == 1}--><a href="home.php?mod=space&do=share&view=all" class="tab">{lang mms_v2ex:v2ex_110}</a><!--{/if}--><!--{if $v2ex['mms_blog'] == 1}--><!--{/if}--><!--{if $v2ex['mms_album'] == 1}--><!--{/if}--><!--{if $v2ex['mms_doing'] == 1}--><!--{/if}-->$v2ex['mms_indexdaohang']<!--{if $v2ex['mms_hot'] == 1}--><a href="forum.php?mod=guide&view=hot" class="tab">{lang mms_v2ex:v2ex_4}</a><!--{/if}--><a href="forum.php?mod=guide&view=new" class="tab">{lang mms_v2ex:v2ex_5}</a><!--{if $_G['uid']}--><a href="home.php?mod=space&do=thread&view=me" class="tab">{lang mms_v2ex:v2ex_6}</a><a href="plugin.php?id=mms_v2ex:myconcernlist" class="tab">{lang mms_v2ex:v2ex_7}</a><!--{/if}--><!--{if $_G['uid']}--><!--{loop $user_conts $user_cont}--><!--{if $user_cont['following'] > '10'}--><a href="home.php?mod=follow" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{else}--><a href="home.php?mod=follow&view=other" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{/if}--><!--{/loop}--><!--{/if}--><a href="group.php?mod=index" class="tab_current">{lang group}</a>
</div>

<div class="cell tbmmu" id="SecondaryTabs">
	<div class="fr">
		<a href="group.php?mod=my">{lang my_group}</a>&nbsp; <li class="fa fa-caret-right gray"></li>
	</div>
	<i class="a"><a href="group.php">{lang mms_v2ex:groupjingxuan}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<!--{loop $first $groupid $group}-->
		<a href="group.php?gid=$groupid">$group[name]</a>&nbsp;&nbsp;&nbsp;&nbsp;
	<!--{/loop}-->
</div>
$v2ex['mms_qunzhujingxuan']
</div>


	<div class="sep20"></div>

	    <div class="box">
	    <div class="cell"><span class="fade"><strong>$_G['setting'][bbname]</strong> / {lang mms_v2ex:v2ex_210}</span></div>

<!--{loop $first $groupid $group}-->
	<div class="cell">
		<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td align="right" width="60"><span class="fade">$group[name]</span></td>
				<td style="line-height: 200%; padding-left: 10px;">
					<!--{loop $lastupdategroup[$groupid] $val}-->
					<a href="forum.php?mod=group&fid=$val[fid]" style="font-size: 14px;">$val[name]</a>&nbsp; &nbsp;
					<!--{/loop}-->
					<a href="group.php?gid=$groupid"><span class="fade" style="font-size: 12px;">{lang more} &rsaquo;</span></a>
				 </td>
			 </tr>
		 </table>
	</div>
<!--{/loop}-->
<div class="inner">
	<table cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td align="right" width="60"><span class="fade">{lang mms_v2ex:v2ex_211}</span></td>
			<td style="line-height: 200%; padding-left: 10px;">
				<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
				<a href="forum.php?mod=group&fid=$val[fid]" style="font-size: 14px;">$val[name]</a>&nbsp; &nbsp;
				<!--{/loop}-->
			 </td>
		 </tr>
	 </table>
</div>

</div>


				<!--{ad/text/wp a_t}--><!--{hook/index_header}--><!--{hook/index_top}-->
						<!--{hook/index_bottom}-->

				</div>

			  </div>
        <div class="c"></div>
        <div class="sep20"></div>
		
<div style="display:none;"><!--{hook/index_side_top}--><!--{hook/index_side_bottom}--></div>
<!--{template common/footer}-->
