<?php exit;?>
			<i class="{if $op == 'basic'} a{/if}"><a href="misc.php?mod=stat&op=basic">{lang basic_situation}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
			<i class="{if $op == 'team'} a{/if}"><a href="misc.php?mod=stat&op=team">{lang manage_team}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
			<!--{if $_G['setting']['memiststatus']}-->
				<i class="{if $op == 'memberist'} a{/if}"><a href="misc.php?mod=stat&op=memberist">{lang member_ist}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
			<!--{/if}-->
			<!--{if $_G['setting']['updatestat']}-->
				<i class="{if $op == 'trend'} a{/if}"><a href="misc.php?mod=stat&op=trend">{lang trend}</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
			<!--{/if}-->
