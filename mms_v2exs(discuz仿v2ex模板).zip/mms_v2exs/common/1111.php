<?php exit;?>
<div class="sep20"></div>
<!--{if $_G['uid']}-->
                    <div class="box">
                        <div class="cell">
                            <table cellpadding="0" cellspacing="0" border="0" width="100%">
                                <tr>
                                    <td width="48" valign="top"><a href="home.php"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$_G[uid]&size=small" class="avatar" border="0" align="default" style="max-width: 48px; max-height: 48px;" /></a></td>
                                    <td width="10" valign="top"></td>
                                    <td width="auto" align="left"><span class="bigger"><a href="home.php">{$_G[member][username]}</a></span>
                                    </td>
                                </tr>
                            </table>
                            <div class="sep10"></div>
                            <!--{loop $user_conts $user_cont}-->
                            <table cellpadding="0" cellspacing="0" border="0" width="100%">
                              <tbody><tr>
                                <td width="33%" align="center">
                                  <!--{if $v2ex['ycsdh1']=='1'}-->
                                    <a href="home.php?mod=follow&do=follower&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['follower']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_102}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='2'}-->
                                    <a href="home.php?mod=follow&do=following&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_103}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='3'}-->
                                    <a href="home.php?mod=follow&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['feeds']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_104}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='4'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['posts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_105}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='5'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['threads']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_106}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='6'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['digestposts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_1}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='7'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=doing" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['doings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_107}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='8'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=blog&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['blogs']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_108}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='9'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=album&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['albums']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_109}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='10'}-->
                                    <a href="home.php?mod=space&do=share&view=all" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['sharings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_110}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh1']=='11'}-->
                                    <a href="home.php?mod=space&do=friend" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_111}</span></a>
                                  <!--{/if}-->
                                </td>
                                <td width="34%" style="border-left: 1px solid rgba(100, 100, 100, 0.4); border-right: 1px solid rgba(100, 100, 100, 0.4);" align="center">
                                  <!--{if $v2ex['ycsdh2']=='1'}-->
                                    <a href="home.php?mod=follow&do=follower&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['follower']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_102}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='2'}-->
                                    <a href="home.php?mod=follow&do=following&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_103}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='3'}-->
                                    <a href="home.php?mod=follow&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['feeds']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_104}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='4'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['posts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_105}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='5'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['threads']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_106}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='6'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['digestposts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_1}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='7'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=doing" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['doings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_107}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='8'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=blog&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['blogs']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_108}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='9'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=album&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['albums']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_109}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='10'}-->
                                    <a href="home.php?mod=space&do=share&view=all" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['sharings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_110}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh2']=='11'}-->
                                    <a href="home.php?mod=space&do=friend" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_111}</span></a>
                                  <!--{/if}-->
                                </td>
                                <td width="33%" align="center">
                                  <!--{if $v2ex['ycsdh3']=='1'}-->
                                    <a href="home.php?mod=follow&do=follower&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['follower']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_102}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='2'}-->
                                    <a href="home.php?mod=follow&do=following&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_103}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='3'}-->
                                    <a href="home.php?mod=follow&uid=$_G[uid]" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['feeds']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_104}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='4'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['posts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_105}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='5'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['threads']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_106}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='6'}-->
                                    <a href="home.php?mod=space&do=thread&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['digestposts']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_1}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='7'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=doing" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['doings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_107}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='8'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=blog&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['blogs']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_108}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='9'}-->
                                    <a href="home.php?mod=space&uid=$_G[uid]&do=album&view=me" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['albums']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_109}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='10'}-->
                                    <a href="home.php?mod=space&do=share&view=all" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['sharings']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_110}</span></a>
                                  <!--{/if}-->
                                  <!--{if $v2ex['ycsdh3']=='11'}-->
                                    <a href="home.php?mod=space&do=friend" class="dark" style="display: block;"><span class="bigger"><!--{$user_cont['following']}--></span><div class="sep3"></div><span class="fade">{lang mms_v2ex:v2ex_111}</span></a>
                                  <!--{/if}-->
                                </td>
                              </tr></tbody>
                            </table>
                            <!--{/loop}-->
                        </div>

                        <div class="cell" style="padding: 5px;">
                            <table cellpadding="0" cellspacing="0" border="0" width="100%">
                                <tr>
                                    <td width="32">
                                      <!--{if $_G['forum']}-->
                                      <!--{if empty($gid)}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" id="newspecialtmp"><img src="$_G['style'][tpldir]/images/flat_compose.png" width="32" border="0" /></a><!--{else}--><a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav"><img src="$_G['style'][tpldir]/images/flat_compose.png" width="32" border="0" /></a><!--{/if}-->
                                      <!--{else}-->
                                      <a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav"><img src="$_G['style'][tpldir]/images/flat_compose.png" width="32" border="0" /></a>
                                      <!--{/if}-->
                                    </td>
                                    <td width="10"></td>
                                    <td width="auto" valign="middle" align="left">
                                      <!--{if $_G['forum']}-->
                                      <!--{if empty($gid)}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" id="newspecialtmp">{lang mms_v2ex:v2ex_112}</a><!--{else}--><a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav">{lang mms_v2ex:v2ex_112}</a><!--{/if}-->
                                      <!--{else}-->
                                      <a onclick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav">{lang mms_v2ex:v2ex_112}</a>
                                      <!--{/if}-->
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="inner"><div class="fr" id="money"><a href="home.php?mod=spacecp&ac=credit&op=base" class="balance_area" style="">
			<!--{loop $_G['setting']['extcredits'] $id $credit}-->
				<!--{if $id!=$creditid}-->
				 <!--{echo getuserprofile('extcredits'.$id);}--><!--{if $credit[img]}--> {$credit[img]}<!--{/if}-->
				<!--{/if}-->
			<!--{/loop}--></a>


</div>


<!--{if $_G[member][newprompt]}-->
<img src="$_G['style'][tpldir]/images/dot_orange.png" align="absmiddle" />&nbsp;<strong><a href="home.php?mod=space&do=notice">$_G[member][newprompt] {lang mms_v2ex:v2ex_113}</a></strong>
<!--{else}-->
<a href="home.php?mod=space&do=notice" class="fade">0 {lang mms_v2ex:v2ex_113}</a>
<!--{/if}-->

                        </div>

                    </div>
<!--{else}-->

                    <div id="smmsq" class="box">
                        <div class="cell">
                            <strong>$_G['setting'][bbname]&nbsp;-&nbsp;$v2ex['mms_wangurl']</strong>
                            <div class="sep5"></div>
                            <span class="fade">$v2ex['mms_miaoshu']</span>
                        </div>
                        <div class="inner">
                            <div class="sep5"></div>
                            <div align="center"><a href="member.php?mod={$_G[setting][regname]}" class="super normal button">{lang mms_v2ex:v2ex_114}</a>
                            <div class="sep5"></div>
                            <div class="sep10"></div>
                            {lang mms_v2ex:v2ex_115} &nbsp;<a href="member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href)">{lang mms_v2ex:v2ex_116}</a></div>
                        </div>
                    </div>

<!--{/if}-->
