<?php exit;?>
<!--{template common/header1}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<!--{if !$_G['inajax']}-->

<div id="Wrapper">
<div class="content">
   <div id="Leftbar"></div>
   <div id="Rightbar">
<!--{subtemplate common/1111}-->
<div class="sep20"></div>
<div class="box">
    <div class="inner" align="center">
<!--{ad/custom_1}-->
    </div>
</div>
</div>



<div id="Main">
<div class="sep20"></div>
<div class="box">
<div class="inner">


	<div class="wp w">
		<!--{if !$param[login]}-->
			<div>
		<!--{else}-->
			<div class="nfl" id="main_succeed" style="display: none">
				<div class="f_c altw">
					<div class="alert_right">
						<p id="succeedmessage"></p>
						<p id="succeedlocation" class="alert_btnleft"></p>
						<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>
					</div>
				</div>
			</div>
			<div id="main_message">
		<!--{/if}-->

<!--{else}-->
	<!--{template common/header_ajax}-->
<!--{/if}-->
<!--{if $param[msgtype] == 1 || $param[msgtype] == 2 && !$_G[inajax]}-->
<style type="text/css">
hr {
    clear: none;
}
</style>
		<div class="f_c">
			<div id="messagetext" class="$alerttype">
				<p class="">$show_message</p>
				<!--{if $url_forward}-->
					<!--{if !$param[redirectmsg]}-->
						<p class="alert_btnleft"><a href="$url_forward">{lang message_forward}</a></p>
					<!--{else}-->
						<p class="alert_btnleft"><a href="$url_forward">{lang attach_forward}</a></p>
					<!--{/if}-->
				<!--{elseif $allowreturn}-->
   <div class="inner"><span class="gray">
        <span class="chevron"><i class="fa fa-angle-left fa-1"></i></span> &nbsp;{lang mms_v2ex:v2ex_122} <a href="javascript:history.back()">{lang mms_v2ex:v2ex_284}</a>
     <br />
        <span class="chevron"><i class="fa fa-angle-left fa-1"></i></span> &nbsp;{lang mms_v2ex:v2ex_122} <a href="{$_G['siteurl']}">$_G[setting][bbname]</a>
    </div>


				<!--{/if}-->
			</div>
			<!--{if $param[login]}-->
				<div id="messagelogin"></div>
				<script type="text/javascript">
ajaxget('member.php?mod=logging&action=login&infloat=yes&frommessage', 'messagelogin');                       </script>
			<!--{/if}-->
		</div>
<!--{elseif $param[msgtype] == 2}-->
		<h3 class="flb"><em>{lang board_message}</em><!--{if $_G[inajax]}--><span><a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']');" title="{lang close}">{lang close}</a></span><!--{/if}--></h3>
		<div class="c altw">
			<div class="$alerttype">$show_message</div>
		</div>
		<p class="o pns">
			<!--{if $param['closetime']}-->
				<span class="z xg1">$param['closetime'] {lang message_closetime}</span>
			<!--{elseif $param['locationtime']}-->
				<span class="z xg1">$param['locationtime'] {lang message_locationtime}</span>
			<!--{/if}-->
			<!--{if $param[login]}-->
				<button type="button" class="pn pnc" onclick="hideWindow('$_GET['handlekey']');showWindow('login', 'member.php?mod=logging&action=login');"><strong>{lang login}</strong></button>
				<!--{if !$_G['setting']['bbclosed']}-->
					<button type="button" class="pn pnc" onclick="hideWindow('$_GET['handlekey']');window.open('member.php?mod={$_G[setting][regname]}');"><em>$_G['setting']['reglinkname']</em></button>
				<!--{/if}-->
				<button type="button" class="pn" onclick="hideWindow('$_GET['handlekey']');"><em>{lang cancel}</em></button>
			<!--{elseif !$param['closetime'] && !$param['locationtime']}-->
				<button type="button" class="pn pnc" id="closebtn" onclick="hideWindow('$_GET['handlekey']');"><strong>{lang confirms}</strong></button>
				<script type="text/javascript" reload="1">if($('closebtn')) {$('closebtn').focus();}</script>
			<!--{/if}-->
		</p>
<!--{else}-->$show_message<!--{/if}-->
<!--{if !$_G['inajax']}-->
		</div>
	</div>



</div></div></div></div>
<div class="c"></div>
<div class="sep20">
	<!--{template common/footer1}-->
<!--{else}-->
	<!--{template common/footer_ajax}-->
<!--{/if}-->
<!--{hook/global_sky}-->
<style type="text/css">hr {clear: none;}</style>
