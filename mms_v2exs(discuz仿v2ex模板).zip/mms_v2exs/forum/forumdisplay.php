<?php exit;?>
<!--{template common/header1}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->

<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->

    <div id="Wrapper">
        <div class="content">
            <div id="Leftbar"></div>
            <div id="Rightbar">

<!--{subtemplate common/1111}-->

<!--{if $_G['forum']['description']}-->
		$_G['forum'][description]
<!--{/if}-->

<script type="text/javascript">
function nofind(){
var img=event.srcElement;
img.src="$_G[style][tpldir]/images/fjd.png";
img.onerror=null;
}
</script>
<div class="sep20"></div>
		<div class="box">
			<!--{hook/forumdisplay_botttt}-->
			<!--{hook/forumdisplay_bottom}-->
			<!--{if $subexists}-->
			      <div class="inner"  style="border-top: 1px solid #e2e2e2;">
			        <strong class="gray">{lang mms_v2ex:v2ex_130}</strong>
			        <!--{template forum/forumdisplay_subforum}-->
			      </div>
			<!--{/if}-->

      <!--{if $recommendgroups }-->
      <style type="text/css">bbss img{ width:24px; height:24px;}</style>
			<div class="inner"  style="border-top: 1px solid #e2e2e2;">
				<strong class="gray">{lang recommended_groups}</strong>
				<!--{loop $recommendgroups $key $group}-->
				<!--{if $_G['forum']['forumcolumns']}-->
        <div class="sep10"></div>
          <bbss><a href="forum.php?mod=group&fid=$group[fid]"><img src="$group[icon]" align="left" alt="$group[name]"></a></bbss> &nbsp; <a href="forum.php?mod=group&fid=$group[fid]">$group[name]</a>
				 <!--{else}-->
         <div class="sep10"></div>
           <bbss><a href="forum.php?mod=group&fid=$group[fid]"><img src="$group[icon]" align="left" alt="$group[name]"></a></bbss> &nbsp; <a href="forum.php?mod=group&fid=$group[fid]">$group[name]</a>
				<!--{/if}-->
				<!--{/loop}-->
          </div>
	  <!--{/if}-->

		</div>
                            

    <!--{if !empty($_G['forum']['recommendlist'])}-->
    <div class="sep20"></div>
    <div class="box">
    <div class="cell"><div class="fr"></div><strong class="gray">{lang forum_recommend}</strong></div>
    <!--{subtemplate forum/recommend}-->
    </div>
    <!--{/if}-->

<!--{if $hotuser}-->
<div class="sep20"></div>
<div class="box">
<div class="cell"><div class="fr"></div><strong class="gray">{lang mms_v2ex:v2ex_281}</strong></div>
	<!--{loop $hotuser $value}-->
<div class="inner">
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
            <td width="28" valign="top" align="center"><a href="home.php?mod=space&uid={$value[authorid]}" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid={$value[authorid]}&size=small" class="avatar" border="0" align="default" style="max-width: 28px; max-height: 28px;"></a></td>
            <td width="10"></td>
            <td width="auto" valign="middle"><span class="item_title"><a href="home.php?mod=space&uid={$value[authorid]}" c="1">{$value[author]}</a></span><span class="small fade">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;{$value[num]}&nbsp;{lang mms_v2ex:v2ex_282}</span>
            </td>
        </tr>
  </tbody></table>
</div>
	<!--{/loop}-->
</div>
<!--{/if}-->

<!--{eval $hotuser = DB::fetch_all("select a.authorid,a.author,count(a.authorid) as num,b.fid from ".DB::table("forum_post")." a left join ".DB::table("forum_forum")." b on b.fid=a.fid where b.`fid`='$_G[fid]' group by a.`authorid` order by `num` desc limit 0,5");}-->

<div class="sep20"></div>
<div class="box">
    <div class="inner" align="center">
{$_G['cache']['plugin']['mms_v2ex']['mms_qjad']}
    </div>
</div>


                    <div class="sep20"></div>




            </div>
            <div id="Main">
                <div class="sep20"></div>

<div id="forum" class="box">



<!--{if $v2ex['mms_jdtbfe']=='1'}-->
    <div class="header">
        <!--{if $_G[forum][banner] && !$subforumonly}--><img src="$_G[forum][banner]" alt="$_G['forum'][name]" width="100%" height="180"/><div class="sep20"></div>
<!--{else}-->
       <!--{if $_G[forum][icon] && !$subforumonly}--><div style="float: left; display: inline-block; margin-right: 10px; margin-bottom: 10px;"><img src="data/attachment/common/$_G[forum][icon]" alt="$_G['forum'][name]" border="0" align="default" width="auo"  width="$_G[forum][extra][iconwidth]" height="$_G[forum][extra][iconwidth]"/></div><!--{/if}-->
      <!--{/if}-->
        <div class="fr f12">

        		<!--{if !empty($forumarchive)}-->
						<a id="forumarchive" href="javascript:;" onmouseover="showMenu(this.id)"><!--{if $_GET['archiveid']}--><span class="snow">$forumarchive[$_GET['archiveid']]['displayname']</span><!--{else}--><span class="snow">{lang forum_archive}</span><!--{/if}--></a>	<span class="snow">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;</span>
						<!--{/if}-->
						<!--{hook/forumdisplay_forumaction}-->

						<!--{if $_G['forum']['ismoderator']}-->
						<!--{if $_G['forum']['recyclebin']}-->
							<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" target="_blank"><span class="snow">{lang forum_recyclebin}</span><span class="snow"></a><span class="snow">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;</span>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->

							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]" ><span class="snow">{lang modcp}</span></a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]"><span class="snow">{lang modcp}</span></a>
							<!--{/if}--><span class="snow">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;</span>

						<!--{/if}-->
                        <!--{/if}-->


        <strong class="gray">$_G[forum][threads]</strong>&nbsp;<span class="snow">{lang mms_v2ex:v2ex_134}</span>

       <!--{hook/forumdisplay_top}-->


		 </div><a href="{$_G['siteurl']}">$_G['setting'][bbname]</a><span class="chevron">&nbsp;&nbsp;<i class="fa fa-angle-right fa-1"></i>&nbsp;&nbsp;</span>$_G['forum'][name]





    <div class="sep10"></div>
    <span class="f12 gray">
			<!--{if $_G['forum']['rules']}-->
										<div id="forum_rules_{$_G[fid]}" style="$collapse['forum_rules'];">
											$_G['forum'][rules]
										</div>
			<!--{/if}-->

<!--{if $moderatedby}--><span class="snow">{lang mms_v2ex:v2ex_135}: $moderatedby</span><!--{/if}-->
    </span>

<!--{if $_G['uid']}-->
   <div class="sep10"></div>

<!--{if !$_GET['archiveid']}--><a href="javascript:;" id="newspecialtmp" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} title="{lang send_posts}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_137}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]';" /></a><!--{/if}-->

<!--{if $_G['group']['allowpostpoll']}-->&nbsp;&nbsp;<a type="button" href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1" value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_138}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_138}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1';" /></a><!--{/if}-->

<!--{if $_G['group']['allowpostreward']}-->&nbsp;&nbsp;<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3" value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_139}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_139}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3';" /></a><!--{/if}-->

<!--{if $_G['group']['allowpostdebate']}-->&nbsp;&nbsp;<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5" value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_140}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_140}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5';" /></a><!--{/if}-->

<!--{if $_G['group']['allowpostactivity']}-->&nbsp;&nbsp;<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4" value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_141}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_141}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4';" /></a><!--{/if}-->

<!--{if $_G['group']['allowposttrade']}-->&nbsp;&nbsp;<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2" value="{lang mms_v2ex:v2ex_142}"><input type="button" class="super normal button" value="{lang mms_v2ex:v2ex_142}" onclick="location.href = 'forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2';" /></a><!--{/if}-->
<!--{/if}-->

    </div>

<!--{/if}-->


<!--{if $v2ex['mms_jdtbfe']=='2'}-->

      <!--{if $_G[forum][banner] && !$subforumonly}--><div style="padding: 10px;margin-bottom: -3px;background: #001d25;border-radius: 3px 3px 0 0;"><img src="$_G[forum][banner]" alt="$_G['forum'][name]" width="800px" height="180px"></div><!--{/if}-->
		<div class="node_header">
			<!--{if $_G[forum][icon] && !$subforumonly}--><div class="node_avatar"><div style="float: left; display: inline-block; margin-right: 10px; margin-bottom: initial!important;"><img src="data/attachment/common/$_G[forum][icon]" border="0" align="default" width="72"></div></div><!--{/if}-->

			<div class="node_info"><div class="fr f12">
				<!--{if $_G['forum']['ismoderator']}-->
				<!--{if $_G['forum']['recyclebin']}-->
					<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" target="_blank"><span class="gray">{lang forum_recyclebin}</span><span class="snow"></a><span class="snow">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;</span>
				<!--{/if}-->
        <!--{hook/forumdisplay_forumaction}-->
				<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->

					<!--{if $_G['forum']['status'] != 3}-->
						<a href="forum.php?mod=modcp&fid=$_G[fid]" ><span class="gray">{lang modcp}</span></a>
					<!--{else}-->
						<a href="forum.php?mod=group&action=manage&fid=$_G[fid]"><span class="gray">{lang modcp}</span></a>
					<!--{/if}--><span class="snow">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;</span>

				<!--{/if}-->
				<!--{/if}-->
		<span class="snow">$_G[forum][threads]</span>&nbsp;<span class="snow">{lang mms_v2ex:v2ex_134}</span>
    <!--{hook/forumdisplay_top}-->
			</div><a href="{$_G['siteurl']}">$_G['setting'][bbname]</a><span class="chevron">&nbsp;&nbsp;<i class="fa fa-angle-right fa-1"></i>&nbsp;&nbsp;</span>$_G['forum'][name]

		    <div class="sep10"></div><div class="sep5"></div>
				<div class="fr" style="padding-left: 10px;">
          <!--{if !$_GET['archiveid']}--><input id="newspecial" type="button" class="super normal button" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} value="{lang mms_v2ex:v2ex_136}{lang mms_v2ex:v2ex_137}"><!--{/if}-->
        </div>
		    <!--{if $_G['forum']['rules']}--><span id="forum_rules_{$_G[fid]}" class="f12">$_G['forum'][rules]</span><!--{/if}-->

		    <!--{if $_G['forum']['rules']}--><div class="sep10"></div><!--{else}--><!--{if $_G[forum][icon] && !$subforumonly}--><div class="sep10"></div><div class="sep20"></div><!--{else}--><div class="sep20"></div><!--{/if}--><!--{/if}-->
				   <div class="node_header_tabs">
						 <a id="{if !$_GET['typeid'] && !$_GET['sortid']}s{/if}links" href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax
                <!--{if $_G['forum']['threadtypes']}-->
							  <!--{if $_GET['typeid']}-->node_header_tab<!--{else}-->node_header_tab_current<!--{/if}-->
							  <!--{else}-->
								<!--{if $_GET['specialtype'] == 'poll'}-->node_header_tab<!--{elseif $_GET['specialtype'] == 'reward'}-->node_header_tab<!--{elseif $_GET['specialtype'] == 'activity'}-->node_header_tab<!--{elseif $_GET['specialtype'] == 'debate'}-->node_header_tab<!--{elseif $_GET['specialtype'] == 'trade'}-->node_header_tab<!--{else}-->node_header_tab_current<!--{/if}-->
								<!--{/if}-->
						 ">{lang all}{lang forum_threads}</a><!--{if $_G['forum']['threadtypes']}--><!--{loop $_G['forum']['threadtypes']['types'] $id $name}--><!--{if $_GET['typeid'] == $id}--><a id="slinks" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax node_header_tab_current">$name</a><!--{else}--><a id="links" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax node_header_tab">$name</a><!--{/if}--><!--{/loop}--><!--{else}--><!--{if $showpoll}--><!--{elseif $showreward}--><!--{elseif $showactivity}--><!--{elseif $showdebate}--><!--{elseif $showtrade}--><!--{else}--><!--{template forum/forumdisplay_subforums}--><!--{/if}-->
<!--{if $showpoll}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax {if $_GET['specialtype'] == 'poll'} node_header_tab_current{else}node_header_tab{/if}">{lang thread_poll}</a><!--{/if}-->
<!--{if $showreward}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax {if $_GET['specialtype'] == 'reward'} node_header_tab_current{else}node_header_tab{/if}">{lang thread_reward}</a><!--{/if}-->
<!--{if $showactivity}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax {if $_GET['specialtype'] == 'activity'} node_header_tab_current{else}node_header_tab{/if}">{lang thread_activity}</a><!--{/if}-->
<!--{if $showdebate}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax {if $_GET['specialtype'] == 'debate'} node_header_tab_current{else}node_header_tab{/if}">{lang thread_debate}</a><!--{/if}-->
<!--{if $showtrade}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="pjax {if $_GET['specialtype'] == 'trade'} node_header_tab_current{else}node_header_tab{/if}">{lang thread_trade}</a><!--{/if}-->
<!--{/if}-->

			    </div>
		    </div>
		</div>
<!--{/if}-->



							<!--{hook/forumdisplay_threadtype_extra}-->
							<!--{if empty($_G['forum']['sortmode'])}-->
								<!--{subtemplate forum/forumdisplay_list}-->
							<!--{else}-->
								<!--{subtemplate forum/forumdisplay_sort}-->
							<!--{/if}-->

</div>

<!--{if $fastpost}-->
<div class="sep20"></div>
<div class="box">
    <div class="cell">
				<!--{template forum/forumdisplay_fastpost}-->
    </div>

    <div class="inner"><div class="fr">
   <!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}--><a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" class="fa_rss" target="_blank" title="RSS">{lang rss_subscribe_this}</a><!--{/if}-->   &nbsp;

<span class="fade">{lang mms_v2ex:v2ex_144}</span></div>
    &nbsp;
    </div>
</div>
<!--{/if}-->

            </div>


        </div>


        <div class="c"></div>
        <div class="sep20"></div>
    </div>



</div>




<!--{if $common_hot}--><!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->
		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->

<div style="display:none;"><!--{hook/forumdisplay_leftside_top}--><!--{hook/forumdisplay_leftside_bottom}--><!--{hook/forumdisplay_modlink}--><!--{hook/forumdisplay_middle}--><!--{hook/forumdisplay_postbutton_top}--><!--{hook/forumdisplay_threadtype_inner}--><!--{hook/forumdisplay_filter_extra}--><!--{hook/forumdisplay_side_top}--><!--{hook/forumdisplay_side_bottom}--></div>

<!--{if $_G['setting']['visitedforums'] && $_G['forum']['status'] != 3}-->
	<div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<td id="v_forums">
					<h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
					<ul class="xl xl1">
						$_G['setting']['visitedforums']
					</ul>
				</td>
			</tr>
		</table>
	</div>
<!--{/if}-->
<!--{if $_G['setting']['threadmaxpages'] > 1 && $page && !$subforumonly}-->
	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}', $page);}</script>
<!--{/if}-->

<!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && empty($_GET['filter']) }-->
	<script type="text/javascript">checkForumnew_handle = setTimeout(function () {checkForumnew($_G[fid], lasttime);}, checkForumtimeout);</script>
<!--{/if}-->

<!--{if empty($_G['setting']['disfixednv_forumdisplay']) }--><script>fixed_top_nv();</script><!--{/if}--><!--{/if}-->

<!--{loop $field8s $field8}-->
<style><!--{$field8['field7']}--></style>
<!--{/loop}-->
<!--{template common/footer1}-->
