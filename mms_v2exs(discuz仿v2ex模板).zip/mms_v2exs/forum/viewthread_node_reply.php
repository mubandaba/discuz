<?php exit;?>
<!--{if !$post['first']}-->
<div  id="pid$post[pid]" summary="pid$post[pid]" class="cell" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>

<!--{eval
$needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);
$postshowavatars = !($_G['setting']['bannedmessages'] & 2 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)));
}-->
<!--{block authorverifys}-->
<!--{loop $post['verifyicon'] $vid}-->
	<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
<!--{/loop}-->
<!--{loop $post['unverifyicon'] $vid}-->
	<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
<!--{/loop}-->
<!--{/block}-->
<!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
	<div id="threadstamp"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
<!--{/if}-->
<!--{if empty($post['deleted'])}-->


    <table cellspacing="0" cellpadding="0" style="width: 100%;">
        <tr>
            <td width="48" valign="top" align="center">
							<!--{if $post['authorid'] && !$post['anonymous']}-->
					      <bbb class="avatar"><a href="home.php?mod=space&uid=$post[authorid]" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$post[authorid]&size=small" class="avatar" border="0" style="max-width: 48px; max-height: 48px;"/></a></bbb>
					    <!--{elseif getstatus($post['status'], 5)}-->
					      <bbb class="avatar"><a href="home.php?mod=space&uid=$post[authorid]" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$post[authorid]&size=small" class="avatar" border="0" style="max-width: 48px; max-height: 48px;"/></a></bbb>
					    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous'] || !$post['authorid'] && !$post['username']}-->
					      <bbb class="avatar"><img src="$_G['setting'][ucenterurl]/images/noavatar_middle.gif" class="avatar" border="0" style="max-width: 48px; max-height: 48px;"/></bbb>
					    <!--{/if}-->
            </td>
            <td width="10" valign="top"></td>
            <td width="auto" valign="top" align="left">
<div class="fr" style="font-size: 12px;">
<div id="thank_area" class="thank_area">


<!--{if $modmenu['thread']}-->
   			<!--{if !$post['first'] && $modmenu['post']}-->
				<label for="manage$post[pid]">
				<a class="thank" style="color: #ccc;"><input type="checkbox" id="manage$post[pid]" class="pc" {if !empty($modclick)}checked="checked" {/if}onclick="pidchecked(this);modclick(this, $post[pid])" value="$post[pid]" autocomplete="off"/>{lang mms_v2ex:v2ex_161}</a>&nbsp;&nbsp;
				</label>
			<!--{/if}-->
<!--{/if}-->
<!--{if $post['authorid'] != $_G['uid']}--><!--{if $_G['uid']}-->
							<a href="javascript:;" onclick="showWindow('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]', 'get', -1);return false;"  class="thank" style="color: #ccc;">{lang report}</a>&nbsp;&nbsp;
<!--{else}--><!--{/if}-->
<!--{/if}-->
<!--{if $_G['setting']['magicstatus']}-->
	<a href="javascript:;" id="mgc_post_$post[pid]" onmouseover="showMenu(this.id)" class="thank" style="color: #ccc;">{lang thread_magic}</a>&nbsp;&nbsp;
<!--{/if}-->
<!--{if $_G['setting']['magicstatus']}-->
	<ul id="mgc_post_$post[pid]_menu" class="p_pop mgcmn" style="display: none;text-align:left;">
	<!--{if $post['first']}-->
		<!--{if !empty($_G['setting']['magics']['bump'])}-->
			<li><a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/bump.small.gif" />$_G['setting']['magics']['bump']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['stick'])}-->
			<li><a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/stick.small.gif" />$_G['setting']['magics']['stick']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['close'])}-->
			<li><a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/close.small.gif" />$_G['setting']['magics']['close']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['open'])}-->
			<li><a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/open.small.gif" />$_G['setting']['magics']['open']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['highlight'])}-->
			<li><a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/highlight.small.gif" />$_G['setting']['magics']['highlight']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['sofa'])}-->
			<li><a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/sofa.small.gif" />$_G['setting']['magics']['sofa']</a></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['magics']['jack'])}-->
			<li><a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/jack.small.gif" />$_G['setting']['magics']['jack']</a></li>
		<!--{/if}-->
		<!--{hook/viewthread_magic_thread}-->
	<!--{/if}-->
	<!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
		<li><a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/repent.small.gif" />$_G['setting']['magics']['repent']</a></li>
	<!--{/if}-->
	<!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
		<li><a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/anonymouspost.small.gif" />$_G['setting']['magics']['anonymouspost']</a><li>
	<!--{/if}-->
	<!--{if !empty($_G['setting']['magics']['namepost'])}-->
		<li><a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/namepost.small.gif" />$_G['setting']['magics']['namepost']</a><li>
	<!--{/if}-->
	<!--{hook/viewthread_magic_post $postcount}-->
	</ul>
	<script type="text/javascript" reload="1">checkmgcmn('post_$post[pid]')</script>
<!--{/if}-->
					<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->

						<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="thank" style="color: #ccc;"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}<!--{/if}--></a>&nbsp;&nbsp;

					<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
						<a  href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page" onClick="showWindow('postappend', this.href, 'get', 0)" class="thank">{lang postappend}</a>&nbsp;&nbsp;
					<!--{/if}-->
<!--{if $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
    <!--{else}-->
<!--{if !$post['first'] && $_G['group']['raterange'] && $post['authorid']}-->
							<a href="javascript:;" onclick="showWindow('rate', 'forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]', 'get', -1);return false;" class="thank">{lang mms_v2ex:v2ex_162}</a>
<!--{/if}-->
<!--{/if}-->
</div>




&nbsp;



					<!--{if $post['invisible'] == 0}-->

					<!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->
						<!--{if $post['first']}-->
							<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page" onclick="showWindow('reply', this.href)"><img src="{IMGDIR}/reply.png" align="absmiddle" border="0" alt="Reply" /></a>
						<!--{else}-->
							<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" onclick="showWindow('reply', this.href)"><img src="{IMGDIR}/reply.png" align="absmiddle" border="0" alt="Reply" /></a>
						<!--{/if}-->
					<!--{/if}-->
					<!--{/if}-->

 &nbsp;

			<!--{if !IS_ROBOT}-->
				<!--{if $post['warned']}-->
					<a href="forum.php?mod=misc&action=viewwarning&tid=$_G[tid]&uid=$post[authorid]" title="{lang warn_get}" class="y" onclick="showWindow('viewwarning', this.href)"><img src="{IMGDIR}/jinggao.png" alt="{lang warn_get}" /></a>
					<!--{else}-->
					<span class="no">
					<strong>
						<a href="{if $post[first]}forum.php?mod=viewthread&tid=$_G[tid]$fromuid{else}forum.php?mod=redirect&goto=findpost&ptid=$_G[tid]&pid=$post[pid]$fromuid{/if}"  {if $fromuid}title="{lang share_url_copy_comment}"{/if} id="postnum$post[pid]" onclick="setCopy(this.href, '{lang post_copied}');return false;">
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->
									$postno[$post[number]]
								<!--{else}-->
									<em>{$post[number]}</em>{$postno[0]}
								<!--{/if}-->
							<!--{/if}-->
						</a>
					</strong>
					</span>
				<!--{/if}-->
			<!--{/if}-->



                </div>
                <div class="sep3"></div>


                <strong>
				<!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
				<!--{if $post['authorid'] && !$post['anonymous']}-->
					<a href="home.php?mod=space&uid=$post[authorid]" class="dark" <!--{if $_self }-->alt="{lang mms_v2ex:v2ex_163}" title="{lang mms_v2ex:v2ex_163}"<!--{/if}-->>$post[author]</a>
				<!--{elseif getstatus($post['status'], 5)}-->
					<a href="home.php?mod=space&uid=$post[authorid]" class="dark" <!--{if $_self }-->alt="{lang mms_v2ex:v2ex_163}" title="{lang mms_v2ex:v2ex_163}"<!--{/if}-->>$post[author]</a>
				<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous'] || !$post['authorid'] && !$post['username']}-->
					$_G[setting][anonymoustext]
				<!--{/if}-->
									</strong>
									<span class="fade small">&nbsp;$post[dateline]&nbsp;
										<!--{if $post['status'] & 8}-->
											<!--{if $_G['setting']['mobile']['mobilecomefrom']}-->{$_G['setting']['mobile']['mobilecomefrom']}<!--{else}-->{lang from_mobile}<!--{/if}-->
										<!--{/if}-->
									</span>


	<!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->

				<!--{if $_G['setting']['ratelogon']}-->

					<span class="ratl">

							<bb class="fade small">&nbsp;<a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" onclick="showWindow('viewratings', this.href)" title="{lang mms_v2ex:v2ex_149} <!--{echo count($postlist[$post[pid]][totalrate]);}--> {lang mms_v2ex:v2ex_148}" style="text-decoration: none;"><span class="xi1">&nbsp;<i class="fa fa-heart"></i>&nbsp;<!--{echo count($postlist[$post[pid]][totalrate]);}-->&nbsp;</span></a></bb>


					</span>


				<!--{else}-->

				<!--{/if}-->

	<!--{else}-->

	<!--{/if}-->
	<!--{if !$post['first'] && $post['replycredit'] > 0}-->
        &nbsp;<span class="icon_ring vm" title="{lang replycredit}+{$post['replycredit']}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}"></span><span class="fade small"></span>
	<!--{/if}-->


<div class="sep5"></div>
                <div class="reply_content">
									<!--{subtemplate forum/viewthread_node_body}-->
									<div class="fr">
										<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
											<a href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">{lang reward_set_bestanswer}</a>
										<!--{/if}-->
										<!--{if !$post['first'] && $post['rewardfloor']}-->
										<style>.pdbts {float: right;}</style>
											<label class="pdbts pdbts_1" style="font-size: 12px;">
												<a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" title="{lang rushreply_hit_title}" class="v">{lang prosit}</a>
												<a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" title="{lang rushreply_hit_title}" class="b">{lang rushreply_hit}</a>
											</label>
										<!--{/if}-->
										<!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
										<style>.pdbts {float: right;}</style>
											<label class="pdbts pdbts_{echo intval($post[stand])}" style="font-size: 12px;">
												<!--{if $post[stand] == 1}--><a class="v" href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&filter=debate&stand=1" title="{lang debate_view_square}">{lang debate_square}</a>
													<!--{elseif $post[stand] == 2}--><a class="v" href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&filter=debate&stand=2" title="{lang debate_view_opponent}">{lang debate_opponent}</a>
													<!--{else}--><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&filter=debate&stand=0" title="{lang debate_view_neutral}">{lang debate_neutral}</a><!--{/if}-->
												<!--{if $post[stand]}-->
													<a class="b" href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" id="voterdebate_$post[pid]" onclick="ajaxmenu(this);doane(event);">{lang debate_support} $post[voters]</a>
												<!--{/if}-->
											</label>
										<!--{/if}-->
									</div>
                </div>

								<!--{if !empty($aimgs[$post[pid]])}-->
								<script type="text/javascript" reload="1">
									aimgcount[{$post[pid]}] = [<!--{echo dimplode($aimgs[$post[pid]]);}-->];
									attachimggroup($post['pid']);
									<!--{if empty($_G['setting']['lazyload'])}-->
										<!--{if !$post['imagelistthumb']}-->
											attachimgshow($post[pid]);
										<!--{else}-->
											attachimgshow($post[pid], 1);
										<!--{/if}-->
									<!--{/if}-->
									var aimgfid = 0;
									<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
										aimgfid = $_G[fid];
									<!--{/if}-->
									<!--{if $post['imagelistthumb']}-->
										attachimglstshow($post['pid'], <!--{echo intval($_G['setting']['lazyload'])}-->, aimgfid, '{$_G[setting][showexif]}');
									<!--{/if}-->
								</script>
								<!--{/if}-->

            </td>
        </tr>
    </table>


<!--{/if}-->
<!--{hook/viewthread_endline $postcount}-->
</div><!--{/if}-->
