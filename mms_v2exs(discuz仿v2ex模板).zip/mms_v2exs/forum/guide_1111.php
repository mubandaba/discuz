<?php exit;?>
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<style>a.indent{ padding-right: 1.0em }</style>
<div class="box">
    <div class="cell"><div class="fr"><a href="forum.php">{lang mms_v2ex:v2ex_145}</a></div><span class="fade"><strong>$_G['setting'][bbname]</strong> / {lang mms_v2ex:v2ex_146}</span></div>
    {$v2ex['mms_indexdanghang']}
</div>
<!--{if $v2ex['fflink']=='1'}-->
<div class="sep20"></div>
    <div id="category_lk" class="box">
        <div class="cell"><span class="fade"><strong>{lang mms_v2ex:v2ex_285}</strong></span></div>
        <!--{eval $flinks8 = DB::fetch_all("SELECT * FROM ".DB::table('common_friendlink')." WHERE `type`= '8' order by displayorder asc;");}-->
            <!--{if $flinks8}-->
            <div class="cell">
            <!--{loop $flinks8 $link8}-->
            <a href="<!--{$link8[url]}-->" title="<!--{$link1[description]}-->" style="font-size: 14px;" class="indent" target="_blank"><!--{$link8[name]}--></a>
            <!--{/loop}-->
            </div>
            <!--{/if}-->
        <!--{eval $flinks4 = DB::fetch_all("SELECT * FROM ".DB::table('common_friendlink')." WHERE `type`= '4' order by displayorder asc;");}-->
            <!--{if $flinks4}-->
            <div class="cell">
            <!--{loop $flinks4 $link4}-->
            <a href="<!--{$link4[url]}-->" title="<!--{$link4[description]}-->" style="font-size: 14px;" class="indent" target="_blank"><!--{$link4[name]}--></a>
            <!--{/loop}-->
            </div>
            <!--{/if}-->
        <!--{eval $flinks2 = DB::fetch_all("SELECT * FROM ".DB::table('common_friendlink')." WHERE `type`= '2' order by displayorder asc;");}-->
            <!--{if $flinks2}-->
            <div class="cell">
            <!--{loop $flinks2 $link2}-->
            <a href="<!--{$link2[url]}-->" title="<!--{$link2[description]}-->" style="font-size: 14px;" class="indent" target="_blank"><!--{$link2[name]}--></a>
            <!--{/loop}-->
            </div>
            <!--{/if}-->
        <!--{eval $flinks1 = DB::fetch_all("SELECT * FROM ".DB::table('common_friendlink')." WHERE `type`= '1' order by displayorder asc;");}-->
            <!--{if $flinks1}-->
            <div class="cell">
            <!--{loop $flinks1 $link1}-->
            <a href="<!--{$link1[url]}-->" title="<!--{$link1[description]}-->" style="font-size: 14px;" class="indent" target="_blank"><!--{$link1[name]}--></a>
            <!--{/loop}-->
            </div>
            <!--{/if}-->
        </div>
<!--{/if}-->
