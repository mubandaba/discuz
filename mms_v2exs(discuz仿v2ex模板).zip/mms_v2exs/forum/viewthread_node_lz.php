<?php exit;?>
<!--{if !$postcount && !$_G['forum_thread']['archiveid'] && $post['first'] }-->
<style id="diy_style" type="text/css">.pippe {margin: 1px 1px;}
.t_fsz {min-height: 100%;}
.rwd {height:auto!important;   height:118px;   min-height:118px;   }
.psth {
    margin: 1em 0 0.5em -20px;
    width: 360px;
}
</style>
<!--{eval
$needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);
$postshowavatars = !($_G['setting']['bannedmessages'] & 2 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)));
}-->
<!--{block authorverifys}-->
<!--{loop $post['verifyicon'] $vid}-->
	<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
<!--{/loop}-->
<!--{loop $post['unverifyicon'] $vid}-->
	<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
<!--{/loop}-->
<!--{/block}-->
<!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
	<div id="threadstamp"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
<!--{/if}-->


	<div id="post_$post[pid]" class="box pl" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>
	    <div class="headers">
				<div class="fr">
<!--{if $post['authorid'] && !$post['anonymous']}-->
  <bbb class="avatar"><a href="home.php?mod=space&uid=$post[authorid]" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$post[authorid]&size=middle" class="avatar" border="0" style="max-width: 73px; max-height: 73px;"/></a></bbb>
  <!--{if $close_leftinfo}--><!--{/if}-->

<!--{elseif getstatus($post['status'], 5)}-->
  <bbb class="avatar"><a href="home.php?mod=space&uid=$post[authorid]" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid=$post[authorid]&size=middle" class="avatar" border="0" style="max-width: 73px; max-height: 73px;"/></a></bbb>
<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous'] || !$post['authorid'] && !$post['username']}-->
<bbb class="avatar"><img src="$_G['setting'][ucenterurl]/images/noavatar_middle.gif" class="avatar" border="0" style="max-width: 73px; max-height: 73px;"/></bbb>
<!--{/if}-->
        </div>
	    <!--{if $_G['forum']['status'] == 3 && $_G['forum_thread']['closed'] < 1}--><!--{if $_G['uid']}--><a href="group.php?mod=my">{lang mms_v2ex:v2ex_group}</a><!--{else}--><a href="group.php">{lang mms_v2ex:v2ex_group}</a><!--{/if}--><!--{else}--><a href="{$_G['siteurl']}">$_G['setting'][bbname]</a><!--{/if}--><span class="chevron">&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</span><a href="$upnavlink">$_G['forum'][name]</a>
	    <div class="sep10"></div>
			<h1>
				 <!--{if !IS_ROBOT}-->
			<!--{if $post['warned']}-->
				<a href="forum.php?mod=misc&action=viewwarning&tid=$_G[tid]&uid=$post[authorid]" title="{lang warn_get}" class="y" onclick="showWindow('viewwarning', this.href)"><img src="{IMGDIR}/warning.gif" alt="{lang warn_get}" /></a>
			<!--{/if}-->
		         <!--{/if}-->
				<span id="thread_subject">$_G[forum_thread][subject]</span>

			<span class="xg1" style="font-size: 14px;">
				<!--{if $_G['forum_thread'][displayorder] == -2}-->({lang moderating})
				<!--{elseif $_G['forum_thread'][displayorder] == -3}-->({lang have_ignored})
				<!--{elseif $_G['forum_thread'][displayorder] == -4}-->({lang draft})
					<!--{if $post['first'] && $post['invisible'] == -3}-->
						<a class="psave" href="forum.php?mod=misc&action=pubsave&tid=$_G[tid]">{lang published}</a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $_G['setting']['threadhidethreshold'] && $_G['forum_thread']['hidden'] >= $_G['setting']['threadhidethreshold']}-->
					<!--{if $_G['forum_thread']['authorid'] == $_G['uid']}--><a class="psave" id="hiderecover" title="{lang hiderecover_tips}" href="forum.php?mod=misc&action=hiderecover&tid=$_G[tid]&formhash={FORMHASH}" onclick="showWindow(this.id, this.href, 'get', 0);">{lang hidden}</a><!--{else}-->({lang hidden})<!--{/if}-->
					&nbsp;
				<!--{/if}-->
				<!--{if $_G['forum_thread']['recommendlevel']}-->
					&nbsp;<img src="{IMGDIR}/recommend_$_G['forum_thread']['recommendlevel'].gif" alt="" title="{lang thread_recommend} $_G['forum_thread'][recommends]" />
				<!--{/if}-->
				<!--{if $_G['forum_thread'][heatlevel]}-->
					&nbsp;<img src="{IMGDIR}/hot_$_G['forum_thread'][heatlevel].gif" alt="" title="{lang heats}: $_G['forum_thread']['heats']" />
				<!--{/if}-->
				<!--{if $_G['forum_thread']['closed'] == 1}-->
					&nbsp;<img src="{IMGDIR}/locked.gif" alt="{lang close}" title="{lang close}" class="vm" />
				<!--{/if}-->

			</span>


			</h1>

					<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
          <div id="topic_votes" class="votes">
							<!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
							<a id="recommend_add" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'" title="{lang maketoponce}" class="vote"><i><li class="fa fa-chevron-up"></li><!--{if $_G['forum_thread']['recommend_add']}-->&nbsp;&nbsp;<!--{else}--><!--{/if}--><span id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</span></i></a>
							<!--{/if}-->
							<!--{if !empty($_G['setting']['recommendthread']['subtracttext'])}-->
							<a id="recommend_subtract" href="forum.php?mod=misc&action=recommend&do=subtract&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate(-{$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_subtract').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][subtracttext]'" title="{lang makebottomonce}" class="vote"><i><li class="fa fa-chevron-down"></li><!--{if $_G['forum_thread']['recommend_sub']}-->&nbsp;&nbsp;<!--{else}--><!--{/if}--><span id="recommendv_subtract"{if !$_G['forum_thread']['recommend_sub']} style="display:none"{/if}>$_G[forum_thread][recommend_sub]</span></i></a>
							<!--{/if}-->
            </div>&nbsp;&nbsp;
            <!--{/if}-->
<small class="gray authi">
    <!--{if $post['authorid'] && !$post['anonymous']}-->
      <a href="home.php?mod=space&uid=$post[authorid]" c="1"><strong>$post[author]</strong></a>$authorverifys
    <!--{elseif getstatus($post['status'], 5)}-->
      <a href="home.php?mod=space&uid=$post[authorid]" c="1"><strong>$post[author]</strong></a>$authorverifys
    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous'] || !$post['authorid'] && !$post['username']}-->
      $_G[setting][anonymoustext]
    <!--{/if}-->
  
<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
  <!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
    <span class="pipe">{lang mms_v2ex:v2ex_0}</span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</a>
  <!--{else}-->
    <span class="pipe">{lang mms_v2ex:v2ex_0}</span>{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}
  <!--{/if}-->
<!--{/if}-->
<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
  <span class="pipe">{lang mms_v2ex:v2ex_0}</span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}</a>
<!--{/if}-->  
  
     <span class="pipe">{lang mms_v2ex:v2ex_0}</span>$post[dateline]<span class="pipe">{lang mms_v2ex:v2ex_0}</span>$_G[forum_thread][views] {lang mms_v2ex:v2ex_147}
	  <!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && $post['first'] }-->
	    <!--{if $_G['forum_thread']['attachment'] == 2 && $_G['group']['allowgetimage'] && (!$_G['setting']['guestviewthumb']['flag'] || $_G['setting']['guestviewthumb']['flag'] && $_G['uid'])}-->
	      <span class="pipe">{lang mms_v2ex:v2ex_0}</span><a href="forum.php?mod=viewthread&tid=$_G[tid]&from=album">{lang view_bigpic}</a>
	    <!--{/if}-->
	      <span class="none"><img src="{IMGDIR}/arw_r.gif" class="vm" alt="{lang replycredit}" /></span>
	    <!--{if !$rushreply}-->
	      <!--{if $ordertype != 1}-->
	        <span class="show pipe">{lang mms_v2ex:v2ex_0}</span><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1" class="show">{lang post_descview}</a>
	      <!--{else}-->
	        <span class="show pipe">{lang mms_v2ex:v2ex_0}</span><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" class="show">{lang post_ascview}</a>
	      <!--{/if}-->
	    <!--{/if}-->
	  <!--{/if}-->
	  <!--{if $post['first']}-->
	  <span class="show pipe">{lang mms_v2ex:v2ex_0}</span><a href="javascript:;" onclick="readmode($('thread_subject').innerHTML, $post[pid]);" class="show">{lang read_mode}</a>
	  <!--{/if}--></small><small class="gray"><!--{hook/viewthread_title_extra}-->&nbsp;&nbsp;&nbsp;&nbsp;</small>


	<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->

							<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="op"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->

						<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
	&nbsp;
						<a href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page" onClick="showWindow('postappend', this.href, 'get', 0)" class="op">APPEND</a><!--{/if}-->

	<!--{if $_G['uid']}--><!--{if $post['authorid'] != $_G['uid']}-->
	&nbsp;
	<a href="javascript:;" onclick="showWindow('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]', 'get', -1);return false;"  class="op">{lang report}</a>
	<!--{/if}-->
	<!--{/if}-->
	    </div>

			<!--{hook/viewthread_beginline}-->


	<!--{if empty($post['deleted'])}-->
	<div id="pid$post[pid]" class="plhin" summary="pid$post[pid]" cellspacing="0" cellpadding="0">
	<tr class="cell">

		<td class="plc"<!--{if $close_leftinfo}--> style="width:100%"<!--{/if}-->>

			<!--{ad ad_a_pr/thread/a_pr/3/$postcount}-->

			<div class="cell pct">
				<!--{ad/thread/a_pt/2/$postcount}-->
				<!--{if empty($ad_a_pr_css)}-->
					<style type="text/css">.pcb{margin-right:0}</style>
					<!--{eval $ad_a_pr_css=1;}-->
				<!--{/if}-->

				<!--{if !$post['first'] && $post['replycredit'] > 0}-->
					<div class="cm">
						<h3 class="psth xs1"><span class="icon_ring vm"></span>
							{lang replycredit} <span class="xw1 xs2 xi1">+{$post['replycredit']}</span> {$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}
						</h3>
					</div>
				<!--{/if}-->

				<!--{subtemplate forum/viewthread_node_body}-->
			</div>

			<!--{if helper_access::check_module('collection') && !$_G['forum']['disablecollect']}-->
				<!--{if $post['relatecollection']}-->
					<div class="cm">
						<h3 class="psth xs1"><span class="icon_ring vm"></span>{lang collection_related}</h3>
						<ul class="mbw xl xl2 cl">
						<!--{loop $post['relatecollection'] $var}-->
							<li>&middot; <a href="forum.php?mod=collection&action=view&ctid=$var[ctid]" title="$var[name]" target="_blank" class="xi2 xw1">$var[name]</a><span class="pipe">|</span><span class="xg1">{lang collection_threadnum}: $var[threadnum], {lang collection_follow}: $var[follownum]</span></li>
						<!--{/loop}-->
						<!--{if $post['releatcollectionmore']}-->
							<li>&middot; <a href="forum.php?mod=collection&tid=$_G[tid]" target="_blank" class="xi2 xw1">{lang more}</a></li>
						<!--{/if}-->
						</ul>
					</div>
					<!--{if $post['sourcecollection']['ctid']}-->
					<div>
						{lang collection_fromctid}
						<form action="forum.php?mod=collection&action=comment&ctid={$ctid}&tid={$_G[tid]}" method="POST" class="ptm pbm cl">
							<input type="hidden" name="ratescore" id="ratescore" />
							<span class="clct_ratestar">
								<span class="btn">
									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',1)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',1,'ratescore')">1</a>
									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',2)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',2,'ratescore')">2</a>
									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',3)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',3,'ratescore')">3</a>
									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',4)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',4,'ratescore')">4</a>
									<a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star',5)" onmouseout="rateStarHover('clct_ratestar_star',0)" onclick="rateStarSet('clct_ratestar_star',5,'ratescore')">5</a>
								</span>
								<span id="clct_ratestar_star" class="star star$memberrate"></span>
							</span>
							&nbsp;<button type="submit" value="submit" class="pn"><span>{lang collection_rate}</span></button>
						</form>
					</div>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
		</td></tr>

	<tr id="_postposition$post['pid']"></tr>



	<!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
	<style>.rate {margin-top: 20px;margin-bottom: 0px;}</style>
	<dl id="ratelog_$post[pid]" class="rate{if !empty($_G['cookie']['ratecollapse'])} rate_collapse{/if}">
		<!--{if $_G['setting']['ratelogon']}-->
			<dd style="margin:0">
		<!--{else}-->
			<dt>
				<!--{if !empty($postlist[$post[pid]]['totalrate'])}-->
					<strong><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" onclick="showWindow('viewratings', this.href)" title="{lang have}{echo count($postlist[$post[pid]][totalrate]);}{lang people_score}, {lang rate_view}"><!--{echo count($postlist[$post[pid]][totalrate]);}--></a></strong>
					<p><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" onclick="showWindow('viewratings', this.href)">{lang rate_view}</a></p>
				<!--{/if}-->
			</dt>
			<dd>
		<!--{/if}-->
			<div id="post_rate_$post[pid]"></div>
			<!--{if $_G['setting']['ratelogon']}-->
				<table class="ratl">
					<tr>
						<th class="xw1"><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" onclick="showWindow('viewratings', this.href)" title="{lang mms_v2ex:v2ex_149}&nbsp;<!--{echo count($postlist[$post[pid]][totalrate]);}-->&nbsp;{lang mms_v2ex:v2ex_148}"><span class="xi1"><i class="fa fa-heart"></i>&nbsp;<!--{echo count($postlist[$post[pid]][totalrate]);}--></span></a></th>
						<!--{loop $post['ratelogextcredits'] $id $score}-->
							<!--{if $score > 0}-->
								<th class="xw1">&nbsp;&nbsp;&nbsp;&nbsp;{$_G['setting']['extcredits'][$id][title]}&nbsp;<i><span class="xi1">+$score</span></i></th>
							<!--{else}-->
								<th class="xw1">&nbsp;&nbsp;&nbsp;&nbsp;{$_G['setting']['extcredits'][$id][title]}&nbsp;<i><span class="xi1">$score</span></i></th>
							<!--{/if}-->
						<!--{/loop}-->
					</tr>
				</table>
			<!--{else}-->
				<ul class="cl">
					<!--{loop $post['ratelog'] $uid $ratelog}-->
						<li>
							<p id="rate_{$post[pid]}_{$uid}" onmouseover="showTip(this)" tip="<strong>$ratelog[reason]</strong>&nbsp;
									<!--{loop $ratelog['score'] $id $score}-->
										<!--{if $score > 0}-->
											<em class='xi1'>{$_G['setting']['extcredits'][$id][title]} + $score $_G['setting']['extcredits'][$id][unit]</em>
										<!--{else}-->
											<span>{$_G['setting']['extcredits'][$id][title]} $score $_G['setting']['extcredits'][$id][unit]</span>
										<!--{/if}-->
									<!--{/loop}-->" class="mtn mbn"><a href="home.php?mod=space&uid=$uid" target="_blank" class="avt"><!--{echo avatar($uid, 'small');}--></a></p>
							<p><a href="home.php?mod=space&uid=$uid" target="_blank">$ratelog[username]</a></p>
						</li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</dd>
	</dl>
	<!--{else}-->
		<div id="post_rate_div_$post[pid]"></div>
	<!--{/if}-->




</div>





	<!--{if !empty($aimgs[$post[pid]])}-->
	<script type="text/javascript" reload="1">
		aimgcount[{$post[pid]}] = [<!--{echo dimplode($aimgs[$post[pid]]);}-->];
		attachimggroup($post['pid']);
		<!--{if empty($_G['setting']['lazyload'])}-->
			<!--{if !$post['imagelistthumb']}-->
				attachimgshow($post[pid]);
			<!--{else}-->
				attachimgshow($post[pid], 1);
			<!--{/if}-->
		<!--{/if}-->
		var aimgfid = 0;
		<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
			aimgfid = $_G[fid];
		<!--{/if}-->
		<!--{if $post['imagelistthumb']}-->
			attachimglstshow($post['pid'], <!--{echo intval($_G['setting']['lazyload'])}-->, aimgfid, '{$_G[setting][showexif]}');
		<!--{/if}-->
	</script>
	<!--{/if}-->
	<!--{else}-->
		<table id="pid$post[pid]" summary="pid$post[pid]" cellspacing="0" cellpadding="0">
		<tbody>
			<tr>
				<!--{if !$close_leftinfo}-->
				<td class="pls"></td>
				<!--{/if}-->
				<td class="plc"<!--{if $close_leftinfo}--> style="width:100%"<!--{/if}-->>
					<div class="pi">
						<strong><a><!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}--><em>{$post[number]}</em>{$postno[0]}<!--{/if}--></a></strong>
					</div>
					<div class="pct">{lang post_deleted}</div>
				</td>
			</tr>
			<tr class="ad">
				<!--{if !$close_leftinfo}-->
				<td class="pls"></td>
				<!--{/if}-->
				<td class="plc"></td>
			</tr>
		</tbody>
	</table>
	<!--{/if}-->
	<!--{hook/viewthread_endline $postcount}-->

	<!--{if $_G['forum_thread']['replycredit'] > 0 || $rushreply}-->
	<div class="subtle">
	<div id="pl_top">
	  <table cellspacing="0" cellpadding="0" style="width:100%">
	    <!--{if $_G['forum_thread']['replycredit'] > 0 }-->
	      <tr>
	        <!--{if !$close_leftinfo}-->
	        <td class="vm">
	        <!--{else}-->
	        <td class="xi1" colspan="2">
	        <!--{/if}-->
	          <img src="{IMGDIR}/thread_prize_s.png" class="hm" alt="{lang replycredit}" />
	            <strong>{$_G['forum_thread']['replycredit']}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]}</strong>
	        <!--{if !$close_leftinfo}-->
	        </td>
	        <td class="xi1" style="font-size: 12px;">
	        <!--{else}-->
	        &nbsp;&nbsp;&nbsp;&nbsp;
	        <!--{/if}-->
	          {lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
	        </td>
	      </tr>
	      <!--{if $rushreply}-->
	      <tr class="ad">
	        <td class="pls"></td>
	        <td class="plc"></td>
	      </tr>
	      <!--{/if}-->
	  <!--{/if}-->

	  <!--{if $rushreply}-->
	    <tr>
	      <!--{if !$close_leftinfo}-->
	      <td class="vm" style="width: 80px;">
	        <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
	        <strong>{lang rushreply}</strong>
	      </td>
	      <td class="xi1" style="font-size: 12px;">
	      <!--{else}-->
	      <td class="xi1" colspan="2" style="font-size: 12px;">
	        <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
	      <!--{/if}-->
	        <!--{if $rushresult[rewardfloor]}-->
	          <span class="y">
	          <!--{if $_G['uid'] == $_G['thread']['authorid'] || $_G['forum']['ismoderator']}--><a href="javascript:;" onclick="showWindow('membernum', 'forum.php?mod=ajax&action=get_rushreply_membernum&tid=$_G[tid]')" class="y tbs"><span>{lang thread_rushreply_statnum}</span></a><!--{/if}-->
            <!--{if !$_GET['checkrush']}-->
                <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="y tbs"><span>{lang rushreply_view}</span></a>&nbsp;&nbsp;
            <!--{/if}-->
	          </span>
	        <!--{/if}-->
	        <!--{if $rushresult[creditlimit] == ''}-->
	          {lang thread_rushreply}&nbsp;
	        <!--{else}-->
	          {lang thread_rushreply_limit} &nbsp;
	        <!--{/if}-->
	        <!--{if $rushresult['timer']}-->
	        <span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushresult['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushresult['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
	        <!--{/if}-->
	        <!--{if $rushresult[stopfloor]}-->
	          {lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
	        <!--{/if}-->
	        <!--{if $rushresult[rewardfloor]}-->
	          {lang thread_rushreply_floor}: $rushresult[rewardfloor]&nbsp;
	        <!--{/if}-->
	        <!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
	          <p class="ptn">
	            <!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;&nbsp;
	            <a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
	          </p>
	        <!--{/if}-->
	      </td>
	    </tr>
	  <!--{/if}-->
	  </table>
	</div>
	</div>
	<!--{/if}-->
<!--{if $post['first'] && $_G[forum_thread][special] == 5 && $_G[forum_thread][displayorder] >= 0}-->
	<div class="subtle">
	<tr class="ad">
		<td class="pls">
		<!--{if !$close_leftinfo}-->
		</td>
		<td class="plc">
		<!--{/if}-->
			<!--{if $post['first'] && $_G[forum_thread][special] == 5 && $_G[forum_thread][displayorder] >= 0}-->
				<ul class="ttp cl">
					<li style="display:inline;margin-left:12px"><strong class="bw0 bg0_all">{lang debate_filter}: </strong></li>
					<li{if !isset($_GET['stand'])} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]" hidefocus="true">{lang all}</a></li>
					<li{if $_GET['stand'] == 1} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=1" hidefocus="true">{lang debate_square}</a></li>
					<li{if $_GET['stand'] == 2} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=2" hidefocus="true">{lang debate_opponent}</a></li>
					<li{if isset($_GET['stand']) && $_GET['stand'] == 0} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=0" hidefocus="true">{lang debate_neutral}</a></li>
				</ul>
			<!--{/if}-->
			<!--{if $_G['forum_thread']['replies']}--><!--{ad/interthread/a_p/$postcount}--><!--{/if}-->
		</td>
	</tr>
	</div>
<!--{/if}-->
	<div class="topic_buttons">
	<div class="fr gray f11" style="line-height: 12px; padding-top: 3px; text-shadow: 0px 1px 0px #fff;">$_G[forum_thread][views]&nbsp;{lang mms_v2ex:v2ex_147}<!--{if $_G['forum_thread']['favtimes']}-->&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;{$_G['forum_thread']['favtimes']}&nbsp;{lang mms_v2ex:v2ex_151}<!--{/if}--><!--{if $_G['forum_thread']['relay']}-->&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;{$_G['forum_thread']['relay']}&nbsp;{lang mms_v2ex:v2ex_152}<!--{/if}--> <!--{if $_G['forum_thread']['sharetimes']}-->&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;{$_G['forum_thread']['sharetimes']}&nbsp;{lang mms_v2ex:v2ex_153}<!--{/if}-->&nbsp;
	</div>
	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" id="k_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang fav_thread}" class="tbs">{lang mms_v2ex:v2ex_154}</a>

	 <!--{if !$post['anonymous'] && $post['first'] && helper_access::check_module('follow')}-->
							&nbsp;<a href="home.php?mod=spacecp&ac=follow&op=relay&tid=$_G[tid]&from=forum" onclick="showWindow('relaythread', this.href, 'get', 0);" title="{lang follow_spread}" class="tbs">{lang thread_realy}</a>
						<!--{/if}-->

	<!--{if $post['first'] && helper_access::check_module('share')}-->
							&nbsp;<a href="home.php?mod=spacecp&ac=share&type=thread&id=$_G[tid]" onclick="showWindow('sharethread', this.href, 'get', 0);" title="{lang share_digest}" class="tbs">{lang mms_v2ex:v2ex_110}</a>
						<!--{/if}-->

						<!--{if !$_G['forum']['disablecollect'] && helper_access::check_module('collection')}-->
							&nbsp;<a href="forum.php?mod=collection&action=edit&op=addthread&tid=$_G[tid]" id="k_collect" onclick="showWindow(this.id, this.href);return false;" title="{lang mms_v2ex:v2ex_155}{$post['releatcollectionnum']}{lang mms_v2ex:v2ex_156}" class="tbs">{lang mms_v2ex:v2ex_157}</a>
						<!--{/if}-->


	        <!--{if $_G['group']['raterange'] && $post['authorid']}-->
							&nbsp;<a href="javascript:;" id="ak_rate" onclick="showWindow('rate', 'forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]', 'get', -1);return false;" title="{lang rate_position}" class="tbs">{lang mms_v2ex:v2ex_148}</a>
			<!--{/if}-->
			<!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}-->
				&nbsp;<a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" onclick="showWindow('rate', this.href, 'get', -1)" class="tbs">{lang removerate}</a>
			<!--{/if}-->
													<!--{if $_G['setting']['magicstatus']}-->&nbsp;
														<a href="javascript:;" id="mgc_post_$post[pid]" onmouseover="showMenu(this.id)" class="tbs">{lang thread_magic}</a>
													<!--{/if}-->
													<!--{if $_G['setting']['magicstatus']}-->
														<ul id="mgc_post_$post[pid]_menu" class="p_pop mgcmn" style="display: none;font-size: 12px;">
														<!--{if $post['first']}-->
															<!--{if !empty($_G['setting']['magics']['bump'])}-->
																<li><a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/bump.small.gif" />$_G['setting']['magics']['bump']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['stick'])}-->
																<li><a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/stick.small.gif" />$_G['setting']['magics']['stick']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['close'])}-->
																<li><a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/close.small.gif" />$_G['setting']['magics']['close']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['open'])}-->
																<li><a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/open.small.gif" />$_G['setting']['magics']['open']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['highlight'])}-->
																<li><a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/highlight.small.gif" />$_G['setting']['magics']['highlight']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['sofa'])}-->
																<li><a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/sofa.small.gif" />$_G['setting']['magics']['sofa']</a></li>
															<!--{/if}-->
															<!--{if !empty($_G['setting']['magics']['jack'])}-->
																<li><a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/jack.small.gif" />$_G['setting']['magics']['jack']</a></li>
															<!--{/if}-->
															<!--{hook/viewthread_magic_thread}-->
														<!--{/if}-->
														<!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
															<li><a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/repent.small.gif" />$_G['setting']['magics']['repent']</a></li>
														<!--{/if}-->
														<!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
															<li><a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/anonymouspost.small.gif" />$_G['setting']['magics']['anonymouspost']</a><li>
														<!--{/if}-->
														<!--{if !empty($_G['setting']['magics']['namepost'])}-->
															<li><a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/namepost.small.gif" />$_G['setting']['magics']['namepost']</a><li>
														<!--{/if}-->
														<!--{hook/viewthread_magic_post $postcount}-->
														</ul>
														<script type="text/javascript" reload="1">checkmgcmn('post_$post[pid]')</script>
													<!--{/if}-->
	</div>
</div></div><!--{/if}-->
