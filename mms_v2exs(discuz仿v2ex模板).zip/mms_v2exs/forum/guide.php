<?php exit;?>
<!--{template common/header1}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->
<style type="text/css">
	.xl2 { background: url({IMGDIR}/vline.png) repeat-y 50% 0; }
		.xl2 li { width: 49.9%; }
			.xl2 li em { padding-right: 10px; }
				.xl2 .xl2_r em { padding-right: 0; }
			.xl2 .xl2_r i { padding-left: 10px; }

			a.xw1:link, a.tab_current:visited, a.tab_current:active {
			    display: inline-block;
			    font-size: 13px;
			    line-height: 13px;
			    padding: 5px 8px 5px 8px;
			    margin-right: 5px;
			    border-radius: 3px;
			    background-color: #334;
			    color: #fff;
			}

			a.xw1:hover {
			    background-color: #445;
			    color: #fff;
			    text-decoration: none;
			}
</style>


<div id="Wrapper">
        <div class="content">
            <div id="Leftbar"></div>
<!--{subtemplate forum/adv_custom}-->
<div id="Main">
<div class="sep20"></div>
<div style="display:none;"><!--{hook/guide_nav_extra}--><!--{hook/guide_top}--><!--{hook/guide_bottom}--></div>
<div class="box">

    <div class="<!--{if $currentview['new']}-->inner<!--{else}-->cell<!--{/if}-->" id="Tabs">

<!--{if $v2ex['mms_digest'] == 1}--><!--{if $currentview['digest']}--><a href="forum.php?mod=guide&view=digest" class="pjax tab_current">{lang mms_v2ex:v2ex_1}</a><!--{else}--><a href="forum.php?mod=guide&view=digest" class="pjax tab">{lang mms_v2ex:v2ex_1}</a><!--{/if}--><!--{/if}--><!--{if $v2ex['mms_newthread'] == 1}--><!--{if $currentview['newthread']}--><a href="forum.php?mod=guide&view=newthread" class="pjax tab_current">{lang mms_v2ex:v2ex_2}</a><!--{else}--><a href="forum.php?mod=guide&view=newthread" class="pjax tab">{lang mms_v2ex:v2ex_2}</a><!--{/if}--><!--{/if}--><!--{if $v2ex['mms_sofa'] == 1}--><!--{if $currentview['sofa']}--><a href="forum.php?mod=guide&view=sofa" class="pjax tab_current">{lang mms_v2ex:v2ex_3}</a><!--{else}--><a href="forum.php?mod=guide&view=sofa" class="pjax tab">{lang mms_v2ex:v2ex_3}</a><!--{/if}--><!--{/if}--><!--{if $v2ex['mms_share'] == 1}--><a href="home.php?mod=space&do=share&view=all" class="tab">{lang mms_v2ex:v2ex_110}</a><!--{/if}--><!--{if $v2ex['mms_blog'] == 1}--><!--{/if}--><!--{if $v2ex['mms_album'] == 1}--><!--{/if}--><!--{if $v2ex['mms_doing'] == 1}--><!--{/if}-->$v2ex['mms_indexdaohang']<!--{if $v2ex['mms_hot'] == 1}--><!--{if $currentview['hot']}--><a href="forum.php?mod=guide&view=hot" class="pjax tab_current">{lang mms_v2ex:v2ex_4}</a><!--{else}--><a href="forum.php?mod=guide&view=hot" class="pjax tab">{lang mms_v2ex:v2ex_4}</a><!--{/if}--><!--{/if}--><!--{if $currentview['new']}--><a href="forum.php?mod=guide&view=new" class="pjax tab_current">{lang mms_v2ex:v2ex_5}</a><!--{else}--><a href="forum.php?mod=guide&view=new" class="pjax tab">{lang mms_v2ex:v2ex_5}</a><!--{/if}--><!--{if $_G['uid']}--><!--{if $currentview['my']}--><a href="home.php?mod=space&do=thread&view=me" class="tab_current">{lang mms_v2ex:v2ex_6}</a><!--{else}--><a href="home.php?mod=space&do=thread&view=me" class="tab">{lang mms_v2ex:v2ex_6}</a><!--{/if}--><a href="plugin.php?id=mms_v2ex:myconcernlist" class="tab">{lang mms_v2ex:v2ex_7}</a><!--{/if}--><!--{if $_G['uid']}--><!--{loop $user_conts $user_cont}--><!--{if $user_cont['following'] > '10'}--><a href="home.php?mod=follow" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{else}--><a href="home.php?mod=follow&view=other" class="tab<!--{if $userlist}-->_current<!--{else}--><!--{/if}-->">{lang mms_v2ex:v2ex_guanzhu}</a><!--{/if}--><!--{/loop}--><!--{/if}--><!--{if $v2ex['mms_group'] == 1}--><a href="group.php?mod=index" class="tab">{lang mms_v2ex:v2ex_group}</a><!--{/if}-->


    </div>

<!--{if $common_hot}-->
<!--{if $currentview['new']}-->
<div class="cell tbmmu" id="SecondaryTabs">
	<div class="fr">
			<!--{loop $_G['setting']['topnavs'][1] $nav}-->
				<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
			<!--{/loop}--><!--{hook/global_usernav_extra999}-->&nbsp; <li class="fa fa-caret-right gray"></li>
  </div>
			<!--{loop $_G['setting']['topnavs'][0] $nav}-->
				<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]&nbsp;&nbsp;&nbsp;&nbsp;<!--{/if}-->
			<!--{/loop}-->
	</div>

<!--{/if}-->



	<!--{if $view == 'index'}-->

				<!--{loop $data $key $list}-->
				<div class="cell item">
					<div class="bm_h">
						<a href="forum.php?mod=guide&view=$key" class="y xi2">{lang more} &raquo;</a>
						<h2>
							<!--{if $key == 'hot'}-->{lang guide_hot}<!--{elseif $key == 'digest'}-->{lang guide_digest}<!--{elseif $key == 'newthread'}-->{lang guide_newthread}<!--{elseif $key == 'new'}-->{lang guide_new}<!--{elseif $key == 'my'}-->{lang guide_my}<!--{/if}-->
						</h2>
					</div>
					 <div class="bm_c">
					 	<div class="xl xl2 cl">
					 		<!--{if $list['threadcount']}-->
					 			<!--{eval $i=0;}-->
					 			<!--{loop $list['threadlist'] $thread}-->
					 			<!--{eval $i++;$newtd=$i%2;}-->
					 			<li{if !$newtd} class="xl2_r"{/if}>
						 			<em>
							 			<!--{if $key == 'hot'}--><span class="xi1">$thread['heats']{lang guide_attend}</span><!--{/if}-->
							 			<!--{if $key == 'new'}-->$thread['lastpost']<!--{/if}-->
						 			</em>

						 			<i>&middot; <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] target="_blank">$thread[subject]</a></i>&nbsp;<span class="xg1"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$list['forumnames'][$thread[fid]]['name']</a></span>
					 			</li>
					 			<!--{/loop}-->
					 		<!--{else}-->
					 				<p class="emp">{lang guide_nothreads}</p>
					 		<!--{/if}-->
					 	</div>
					</div>
				</div>
				<!--{/loop}-->

			<!--{else}-->
				<!--{loop $data $key $list}-->
				<div id="threadlist">

						<div id="forumnew" style="display:none"></div>

							<!--{subtemplate forum/guide_list_row}-->

				</div>
				<!--{/loop}-->
			<!--{/if}-->
      <!--{if $multipage}-->
      <DIV id="pg" style="background-image: url('$_G['style'][tpldir]/images/shadow_light.png'); background-size: 20px 20px; background-repeat: repeat-x; padding: 1px;">
      $multipage
      </DIV>
      <!--{/if}-->
</div>
<!--{/if}-->




<div class="sep20"></div>

                <!--{subtemplate forum/guide_1111}-->
<div class="sep20"></div>

            </div>


        </div>




        <div class="c"></div>



<!--{template common/footer1}-->
