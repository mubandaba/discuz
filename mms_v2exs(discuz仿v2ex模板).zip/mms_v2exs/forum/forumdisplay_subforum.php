<?php exit;?>

<div class="sep10"></div>

	<bbb id="subforum_{$_G[forum][fid]}" style="$collapse[subforum]">

			<!--{loop $sublist $sub}-->
			<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
			<!--{if $_G['forum']['forumcolumns']}-->
				<!--{if $sub['orderid'] && ($sub['orderid'] % $_G['forum']['forumcolumns'] == 0)}-->
					</tr>
					<!--{if $_G['forum']['orderid'] < $_G['forum']['forumcolumns']}-->
						<tr class="fl_row">
					<!--{/if}-->
				<!--{/if}-->
				<td class="fl_g" width="$_G[forum][forumcolwidth]">
					<div class="fl_icn_g"{if !empty($sub[extra][iconwidth]) && !empty($sub[icon])} style="width:{$sub[extra][iconwidth]}px;"{/if}>
					<!--{if $sub[icon]}-->
						$sub[icon]
					<!--{else}-->
						<a href="$forumurl"{if $sub[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" /></a>
					<!--{/if}-->
					</div>
					<dl{if !empty($sub[extra][iconwidth]) && !empty($sub[icon])} style="margin-left: {$sub[extra][iconwidth]}px;"{/if}>
						<dt><a href="$forumurl" {if !empty($sub[redirect])}target="_blank"{/if} style="{if !empty($sub[extra][namecolor])}color: {$sub[extra][namecolor]};{/if}">$sub[name]</a><!--{if $sub[todayposts] && !$sub['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}"> ($sub[todayposts])</em><!--{/if}--></dt>
						<!--{if empty($sub[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($sub[threads])}--></em>, <em>{lang forum_posts}: <!--{echo dnumber($sub[posts])}--></em></dd><!--{/if}-->
						<dd>
						<!--{if $sub['permission'] == 1}-->
							{lang private_forum}
						<!--{else}-->
							<!--{if $sub['redirect']}-->
								<a href="$forumurl" class="xi2">{lang url_link}</a>
							<!--{elseif is_array($sub['lastpost'])}-->
								<!--{if $_G['forum']['forumcolumns'] < 3}-->
									<a href="forum.php?mod=redirect&tid=$sub[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($sub[lastpost][subject], 30)}--></a> <cite>$sub[lastpost][dateline] <!--{if $sub['lastpost']['author']}-->$sub['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
								<!--{else}-->
									<a href="forum.php?mod=redirect&tid=$sub[lastpost][tid]&goto=lastpost#lastpost">{lang forum_lastpost}: $sub[lastpost][dateline]</a>
								<!--{/if}-->
							<!--{else}-->
								{lang never}
							<!--{/if}-->
						<!--{/if}-->
						<!--{hook/forumdisplay_subforum_extra $sub[fid]}-->
						</dd>
					</dl>
				</td>
			<!--{else}-->



					<!--{if $sub[icon]}-->
						<bsss>$sub[icon] </bsss>
                    <style type="text/css">
                    bsss img{ width:24px; height:24px;}
                    </style>


					<!--{else}-->
						<img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" border="0" align="absmiddle" width="22" height="22"/>
					<!--{/if}-->

                &nbsp; <a href="$forumurl" {if !empty($sub[redirect])}target="_blank"{/if} style="{if !empty($sub[extra][namecolor])}color: {$sub[extra][namecolor]};{/if}">$sub[name]</a>

 <div class="sep10"></div>
					<!--{hook/forumdisplay_subforum_extra $sub[fid]}-->



			</tr>
			<tr class="fl_row">
			<!--{/if}-->
			<!--{/loop}-->
			$_G['forum']['endrows']

	</bbb>
