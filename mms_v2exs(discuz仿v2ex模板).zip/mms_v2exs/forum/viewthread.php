<?php exit;?>
<!--{template common/header1}-->
<!--{eval if(!function_exists('init_7ZhZHFEKsWkbLiSs'))include DISCUZ_ROOT.'./source/plugin/mms_v2ex/common.php'; if(!function_exists('init_7ZhZHFEKsWkbLiSs')) exit('Authorization error!');}-->
<!--{eval include_once DISCUZ_ROOT.'./source/plugin/mms_v2ex/v2ex.php'}-->

<style id="diy_style" type="text/css">
.m_c .c {padding: 10px 10px 10px;padding-top: 10px;padding-right: 10px;padding-bottom: 10px;padding-left: 10px;}
attach_nopermission {width: 100%;}
#ct {min-height: 100%; }
#threadpage {height: 30px; }
.pbg {height: 100%;}
.jammer {
    font-size: 8px;
    color: #FFF;
}
.ml {
    font-size: 12px;
    border: 0px solid #ccc;
    width: 100%;
}
.blockcode {
    border-radius: 5px;
    margin: 10px 0;
    background: #F7F7F7;
    color: #666;
    padding: 0px 0 5px 10px;
    border: 1px solid #CCC;
    background: #F7F7F7 url(/static/image/common/codebg.gif) repeat-y 0 0;
}
.t_f li {
    margin-left: 0.4em;
    padding-left: 10px;
    list-style-type: decimal-leading-zero;
    font-family: Monaco,Consolas,'Lucida Console','Courier New',serif;
    font-size: 12px;
    line-height: 1.8em;
}
.blockcode ul li, ol li {
    padding-left: 22px;
}
.blockcode em {
    margin-left: 43px;
    color: #369 !important;
    font-size: 12px;
    cursor: pointer;
}
  .modact {
    padding: 0px 0 0;
}
#groupicon .vm {margin-top: -3px; }
.subtle {
    height: 45px;
}
.pl .blockcode {
    padding: 10px 10px 10px 30px;
}
.pl .quote {
    padding-bottom: 5px;
    background: #F9F9F9 url() no-repeat 20px 6px;
}
.pl .quote, .pl .blockcode {
    padding: 10px 10px 10px 16px;
}
.pl .quote blockquote {
    padding: 0 0 5px 0;
    background: url() no-repeat 100% 100%;
}
.pl .blockcode ol li {
    padding-left: 18px;
}
.pl .blockcode ol {
    margin: 0 0 0 22px !important;
}
</style>

<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
<!--{if $modmenu['thread'] || $modmenu['post']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>

<style id="diy_style" type="text/css"></style>
<!--[diy=diynavtop]--><div id="diynavtop" class="area"></div><!--[/diy]-->
<!--{if $modmenu['post']}-->
	<div id="mdly" class="fwinmask" style="display:none;z-index:350;">
		<table cellspacing="0" cellpadding="0" class="fwin" style="width: 100%;">
			<tr>
				<td class="t_l"></td>
				<td class="t_c"></td>
				<td class="t_r"></td>
			</tr>
			<tr>
				<td class="m_l">&nbsp;&nbsp;</td>
				<td class="m_c">
					<div class="f_c">
						<div class="c">
							<h3>{lang admin_select}&nbsp;<strong id="mdct" class="xi1"></strong>&nbsp;{lang piece}: </h3>
							<!--{if $_G['forum']['ismoderator']}-->
								<!--{if $_G['group']['allowwarnpost']}--><a href="javascript:;" onclick="modaction('warn')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><a href="javascript:;" onclick="modaction('banpost')">{lang modmenu_banpost}</a><span class="pipe">|</span><!--{/if}-->
								<!--{if $_G['group']['allowdelpost'] && !$rushreply}--><a href="javascript:;" onclick="modaction('delpost')">{lang modmenu_deletepost}</a><span class="pipe">|</span><!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}--><a href="javascript:;" onclick="modaction('stickreply')">{lang modmenu_stickpost}</a><span class="pipe">|</span><!--{/if}-->
							<!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}--><a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span><!--{/if}-->
						</div>
					</div>
				</td>
				<td class="m_r"></td>
			</tr>
			<tr>
				<td class="b_l"></td>
				<td class="b_c"></td>
				<td class="b_r"></td>
			</tr>
		</table>
	</div>
<!--{/if}-->

<!--{hook/viewthread_top}-->
<!--{ad/text/wp a_t}-->

<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>




<div id="Wrapper">
		<div class="content">
				<div id="Leftbar"></div>
				<div id="Rightbar">

					<!--{subtemplate common/1111}-->
<!--{if $_G['forum']['status'] == 3 && $_G['forum_thread']['closed'] < 1}-->
<style type="text/css">
body { background-color: #efefef; background-image: url(data/attachment/group/$_G[forum][banner]); background-repeat: no-repeat; background-attachment: fixed; background-position: center 0; background-size: cover; }
#Wrapper{ background-color: transparent; animation-delay: 2s; -webkit-animation-delay: 2s; animation: fadein 5s; -webkit-animation: fadein 5s; }
@-webkit-keyframes fadein { from { background-color: rgba(239, 239, 239, 255); } to { background-color: rgba(239, 239, 239, 0); } }
@keyframes fadein { from { background-color: rgba(239, 239, 239, 255); } to { background-color: rgba(239, 239, 239, 0); } }
#Main, #Top, #Bottom, #Rightbar { opacity: 0.95; }
</style>
<!--{if $_G['forum']['description']}-->
<div class="sep20"></div>
<div id="forum_rules_{$_G[fid]}" style="$collapse['forum_rules'];">
<div class=box>
    <div class=inner>
								$_G['forum'][description]
        </div></div>
</div>
<!--{/if}-->
<!--{else}-->
          <!--{if $_G['forum']['description']}-->
          	$_G['forum'][description]
          <!--{/if}-->
<!--{/if}-->


 <!--{if $post['relateitem'] }-->
<div class="sep20"></div>
<div class="box">
<div class="cell"><div class="fr"></div><strong class="gray">{lang related_thread}</strong></div>
  <!--{loop $post['relateitem'] $var}-->
  <div class="cell">
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
            <td width="auto" valign="middle">
                <span class="item_hot_topic_title">
                <a href="forum.php?mod=viewthread&tid=$var[tid]">$var[subject]</a>
                </span>
            </td>
        </tr>
    </tbody></table>
  </div>
  <!--{/if}-->
</div>
<!--{/if}-->

<!--{if $hotuser}-->
<div class="sep20"></div>
<div class="box">
<div class="cell"><div class="fr"></div><strong class="gray">{lang mms_v2ex:v2ex_281}</strong></div>
	<!--{loop $hotuser $value}-->
<div class="inner">
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
            <td width="28" valign="top" align="center"><a href="home.php?mod=space&uid={$value[authorid]}" c="1"><img src="$_G['setting'][ucenterurl]/avatar.php?uid={$value[authorid]}&size=small" class="avatar" border="0" align="default" style="max-width: 28px; max-height: 28px;"></a></td>
            <td width="10"></td>
            <td width="auto" valign="middle"><span class="item_title"><a href="home.php?mod=space&uid={$value[authorid]}" c="1">{$value[author]}</a></span><span class="small fade">&nbsp;{lang mms_v2ex:v2ex_0}&nbsp;{$value[num]}&nbsp;{lang mms_v2ex:v2ex_282}</span>
            </td>
        </tr>
  </tbody></table>
</div>
	<!--{/loop}-->
</div>
<!--{/if}-->

<!--{eval $hotuser = DB::fetch_all("select a.authorid,a.author,count(a.authorid) as num,b.fid from ".DB::table("forum_post")." a left join ".DB::table("forum_forum")." b on b.fid=a.fid where b.`fid`='$_G[fid]' group by a.`authorid` order by `num` desc limit 0,5");}-->

          <div class="sep20"></div>
          <div class="box">
              <div class="inner" align="center">
          {$_G['cache']['plugin']['mms_v2ex']['mms_qjad']}
              </div>
          </div>

<div class="sep20"></div>
				</div>
				<div id="Main">
						<div class="sep20"></div>

<div id="ct" class="wp">
<div id="viewthread">

	<!--{hook/viewthread_title_row}-->


	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
	<!--{eval continue;}-->
	<!--{/if}-->
	<!--{subtemplate forum/viewthread_node_lz}-->
	<!--{eval $postcount++;}-->
	<!--{/loop}-->

	<!--{if $_G['page'] > 1}--><!--{else}--><div class="sep20"></div><!--{/if}-->
	<div class="box">
	<div class="cell"><div class="fr" style="margin: -3px -5px 0px 0px;">

							<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
								<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$post[authorid]"  class="tag">{lang mms_v2ex:v2ex_158}</a>
							<!--{elseif !$_G['forum_thread']['archiveid']}-->
								<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page"  class="tag">{lang mms_v2ex:v2ex_159}</a>
							<!--{/if}-->
							<!--{if $_G['page'] > 1}--><a href="forum.php?mod=viewthread&tid=$_G[tid]$fromuid" class="tag">{lang mms_v2ex:v2ex_164}</a><!--{/if}-->
	</div>
	    <span class="gray">$_G[forum_thread][allreplies] {lang mms_v2ex:v2ex_160}
				<!--{if $modmenu['thread']}-->
				&nbsp;<strong class="snow">|</strong>
				<!--{if $_G['page'] > 1}-->$_G[forum_thread][subject]<!--{else}-->
					<bbs id="modmenu" class="xi2 pbm" style="font-size: 12px;">
						<!--{eval $modopt=0;}-->
						<!--{if $_G['forum']['ismoderator']}-->
							<!--{if $_G['group']['allowdelpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(3, 'delete')">{lang modmenu_deletethread}</a><!--{/if}-->
							<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(3, 'bump')">{lang modmenu_updown}</a><!--{/if}-->
							<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(1, 'stick')">{lang modmenu_stickthread}</a><!--{/if}-->
							<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('live')">{lang modmenu_live}</a><!--{/if}-->
							<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(1, 'highlight')">{lang modmenu_highlight}</a><!--{/if}-->
							<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(1, 'digest')">{lang modmenu_digestpost}</a><!--{/if}-->
							<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(1, 'recommend')">{lang modmenu_recommend}</a><!--{/if}-->
							<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('stamp')">{lang modmenu_stamp}</a><!--{/if}-->
							<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('stamplist')">{lang modmenu_icon}</a><!--{/if}-->
							<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(4)"><!--{if !$_G['forum_thread']['closed']}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></a><!--{/if}-->
							<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(2, 'move')">{lang modmenu_move}</a><!--{/if}-->
							<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(2, 'type')">{lang modmenu_type}</a><!--{/if}-->
							<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
								<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('copy')">{lang modmenu_copy}</a><!--{/if}-->
								<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('merge')">{lang modmenu_merge}</a><!--{/if}-->
								<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('refund')">{lang modmenu_restore}</a><!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('split')">{lang modmenu_split}</a><!--{/if}-->
							<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('repair')">{lang modmenu_repair}</a><!--{/if}-->
							<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('restore', '', 'archiveid={$_G[forum_thread][archiveid]}')">{lang modmenu_archive}</a><!--{/if}-->
							<!--{if $_G['forum_firstpid']}-->
								<!--{if $_G['group']['allowwarnpost']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('warn', '$_G[forum_firstpid]')">{lang modmenu_warn}</a><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('banpost', '$_G[forum_firstpid]')">{lang modmenu_banthread}</a><!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="javascript:;" onclick="modaction('removereward')">{lang modmenu_removereward}</a><!--{/if}-->
							<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}--><span class="pippe">|</span><a href="javascript:;" onclick="modthreads(5, 'recommend_group');return false;">{lang modmenu_grouprecommend}</a><!--{/if}-->
							<!--{if $_G['group']['allowmanagetag']}--><span class="pippe">|</span><a href="javascript:;" onclick="showWindow('mods', 'forum.php?mod=tag&op=manage&tid=$_G[tid]', 'get', 0)">{lang post_tag}</a><!--{/if}-->
							<!--{if $_G['group']['alloweditusertag']}--><span class="pippe">|</span><a href="javascript:;" onclick="showWindow('usertag', 'forum.php?mod=misc&action=usertag&tid=$_G[tid]', 'get', 0)">{lang usertag}</a><!--{/if}-->
						<!--{/if}-->
						<!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++}--><span class="pippe">|</span><a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id=$_G['tid']">{lang modmenu_pusharticle}</a><!--{/if}-->
						<!--{hook/viewthread_modoption}-->
					</bbs><!--{/if}-->
				<!--{/if}-->
	    </span>

	</div>

	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
	<!--{eval continue;}-->
	<!--{/if}-->
	<!--{subtemplate forum/viewthread_node_reply}-->
	<!--{eval $postcount++;}-->
	<!--{/loop}-->

	<div id="postlistreply" class="pl"><div id="post_new" class="cell viewthread_table" style="display: none;"></div></div>
	<!--{if $_G['blockedpids']}-->
		<div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>
		<div id="hiddenposts"></div>
	<!--{/if}-->
  <!--{if $multipage}-->
  <DIV style="background-image: url('$_G['style'][tpldir]/images/shadow_light.png'); background-size: 20px 20px; background-repeat: repeat-x; padding: 1px;">
  $multipage
  </DIV>
  <!--{/if}-->
</div>
</div>




<div class="sep20"></div>
<div class="box">
    <div class="cell"><div class="fr"><a href="javascript:scroll(0,0)"><strong>↑</strong> {lang mms_v2ex:v2ex_165}</a></div>
        {lang mms_v2ex:v2ex_166}
    </div>
    <div class="cell">
<!--{if $fastpost}-->
	<!--{subtemplate forum/viewthread_fastpost}-->
<!--{/if}-->

<!--{hook/viewthread_bottom}-->

</div>
<div class="inner">
		<div class="fr">
		<!--{if !$close_leftinfo}-->

	<a href="$upnavlink">← {lang mms_v2ex:v2ex_122}$_G['forum'][name]</a>

		<!--{/if}-->
		</div>
		&nbsp;
</div>
</div>



</div>




<form method="post" autocomplete="off" name="modactions" id="modactions">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="optgroup" />
	<input type="hidden" name="operation" />
	<input type="hidden" name="listextra" value="$_GET[extra]" />
	<input type="hidden" name="page" value="$page" />
</form>

$_G['forum_tagscript']



<!--{hook/viewthread_middle}-->
<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->




<!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->
	<div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<td id="v_forums">
					<h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
					<ul class="xl xl1">
						$_G['setting']['visitedforums']
					</ul>
				</td>
			</tr>
		</table>
	</div>
<!--{/if}-->
<!--{if $_G['medal_list']}-->
<!--{loop $_G['medal_list'] $medalid $medal}-->
	<div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">
		<div class="tip_horn"></div>
		<div class="tip_c">
			<h4>$medal[name]</h4>
			<p>$medal[description]</p>
		</div>
	</div>
<!--{/loop}-->
<!--{/if}-->

<!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
	<script type="text/javascript">
	new lazyload();
	</script>
<!--{/if}-->

<!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->
	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid=$_GET[authorid]<!--{/if}-->', $page);}</script>
<!--{/if}-->
</div>











<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>
<!--{if $_G['relatedlinks'] || $_GET['highlight']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		{eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight'])));}
		<!--{loop $highlights $word}-->
		{eval $key++;}
		relatedlink[$key] = {'sname':'$word', 'surl':''};
		<!--{/loop}-->
		relatedlinks('postmessage_$_G[forum_firstpid]');
	</script>
<!--{/if}-->

<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->
	<script type="text/javascript">saveUserdata('forum_'+discuz_uid, '')</script>
<!--{/if}-->

<script type="text/javascript">
<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
function showsetcover(obj) {
	if(obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {
		var defheight = $_G['setting']['forumpicstyle']['thumbheight'];
		var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];
		var newimgid = 'showcoverimg';
		var imgsrc = obj.src ? obj.src : obj.file;
		if(!imgsrc) return;

		var tempimg=new Image();
		tempimg.src=imgsrc;
		if(tempimg.complete) {
			if(tempimg.width < defwidth || tempimg.height < defheight) return;
		} else {
			return;
		}
		if($(newimgid) && obj.id != newimgid) {
			$(newimgid).id = 'img'+Math.random();
		}
		if($(newimgid+'_menu')) {
			var menudiv = $(newimgid+'_menu');
		} else {
			var menudiv = document.createElement('div');
			menudiv.className = 'tip tip_4 aimg_tip';
			menudiv.id = newimgid+'_menu';
			menudiv.style.position = 'absolute';
			menudiv.style.display = 'none';
			obj.parentNode.appendChild(menudiv);
		}
		menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_'+newimgid+'\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl='+imgsrc+'">{lang set_cover}</a></div>';
		obj.id = newimgid;
		showMenu({'ctrlid':newimgid,'pos':'12'});
	}
	return;
}
<!--{/if}-->
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod_'+values['fuid']);
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang nofollow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
<!--{if $_G['blockedpids']}-->
var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];
<!--{/if}-->
<!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->
fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});
<!--{elseif empty($_G['setting']['disfixednv_viewthread'])}-->
fixed_top_nv();
<!--{/if}-->
</script>

<div class="c"></div>
<div class="sep20"></div>
<div style="display:none;"><!--{hook/viewthread_postbutton_top}--><!--{hook/viewthread_beginline}--><!--{hook/viewthread_title_extra}--></div>
<!--{loop $field8s $field8}-->
<style><!--{$field8['field7']}--></style>
<!--{/loop}-->
<!--{template common/footer1}-->
