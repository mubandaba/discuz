<?php exit;?>
<div id="Rightbar">
<!--{subtemplate common/1111}-->
<div class="sep20"></div>
<!--{if $_G['page'] == 1 && $_G['forum']['description']}-->
  <div id="forum_rules_{$_G[fid]}" style="$collapse['forum_rules'];">
    $_G['forum'][description]
  </div>
<!--{/if}-->

<div class="box">
<div class="inner" align="center">
{$_G['cache']['plugin']['mms_v2ex']['mms_qjad']}
</div>
</div>


<div class="sep20"></div>
<div class="box" id="TopicsHot">
<div class="cell"><span class="fade">{lang mms_v2ex:v2ex_123}</span></div>
{$v2ex['dayhot']}
</div>
<div class="sep20"></div>
<div class="box">
<div class="cell"><div class="fr"></div><span class="fade">{lang mms_v2ex:v2ex_124}</span></div>
<div class="cell">
{$v2ex['hotjiedian']}
</div>

<!--{if $view != 'index' && $view != 'my'}--><div class="inner"><a href="forum.php?mod=guide&view=$view&rss=1" target="_blank"><img src="$_G['style'][tpldir]/images/rss.png" align="absmiddle" style="margin-top:-3px;" border="0" /></a>&nbsp; <a href="forum.php?mod=guide&view=$view&rss=1" target="_blank">RSS</a></div><!--{/if}-->

</div>
<div class="sep20"></div>
<div class="box">
<div class="cell"><div class="fr"></div><span class="fade">{lang mms_v2ex:v2ex_125}</span></div>
<div class="inner">
{$v2ex['newgroup']}
</div>
</div>
<div class="sep20"></div>
<div class="box">
<div class="cell"><span class="fade">{lang mms_v2ex:v2ex_126}</span></div>
<div class="cell">
<table cellpadding="5" cellspacing="0" border="0" width="100%">
{$v2ex['yunxing']}
</table>
</div>
<div class="inner">
<span class="chevron"><i class="fa fa-angle-right fa-1"></i>&nbsp;</span><a href="misc.php?mod=ranklist&type=member">{lang mms_v2ex:v2ex_127}</a>
<div class="sep5"></div>
<span class="chevron"><i class="fa fa-angle-right fa-1"></i>&nbsp;</span><a href="misc.php?mod=ranklist&type=thread&view=heats&orderby=thisweek">{lang mms_v2ex:v2ex_128}</a>
</div>
</div>
<!--{if $v2ex['fflink']=='2'}-->
<!--{eval $flinks = DB::fetch_all("SELECT * FROM ".DB::table('common_friendlink')." order by displayorder asc ;");}-->
<div class="sep20"></div>
    <div id="category_lk" class="box">
        <div class="cell"><span class="fade">{lang mms_v2ex:v2ex_285}</span></div>
          <div class="inner">
            <!--{loop $flinks $link}-->
            <a href="<!--{$link[url]}-->" title="<!--{$link[description]}-->" style="font-size: 14px;" class="item_node" target="_blank"><!--{$link[name]}--></a>
            <!--{/loop}-->
          </div>
    </div>
<!--{/if}-->
<div class="sep20"></div>
</div>
