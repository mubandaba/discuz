<?php exit;?>
<div class="exfm cl">
	<div class="sinf sppoll z">
		<dl>
			<dt><span class="rq">*</span><label for="affirmpoint">{lang debate_square_point}:</label></dt>
			<dd><textarea name="affirmpoint" id="affirmpoint" class="pt" tabindex="1" style="width:210px;">$debate[affirmpoint]</textarea></dd>
			<dt><span class="rq">*</span><label for="negapoint">{lang debate_opponent_point}:</label></dt>
			<dd><textarea name="negapoint" id="negapoint" class="pt" tabindex="1" style="width:210px;">$debate[negapoint]</textarea></dd>
		</dl>
	</div>
	<div class="sadd z">
		<dl>
			<dt><label for="endtime">{lang endtime}:</label></dt>
			<dd class="hasd cl">
				<input type="text" name="endtime" id="endtime" class="px" onclick="showcalendar(event, this, true)" autocomplete="off" value="$debate[endtime]" tabindex="1" />
				<a href="javascript:;" class="dpbtn" onclick="showselect(this, 'endtime')">^</a>
			</dd>
			<dt><label for="umpire">{lang debate_umpire}:</label></dt>
			<dd>
				<p><input type="text" name="umpire" id="umpire" class="px" onblur="checkuserexists(this.value, 'checkuserinfo')" value="$debate[umpire]" tabindex="1" /><span id="checkuserinfo"></span></p>
			</dd>
			<!--{hook/post_debate_extra}-->
		</dl>
	</div>
</div>

<script type="text/javascript" reload="1">
function checkuserexists(username, objname) {
	if(!username) {
		$(objname).innerHTML = '';
		return;
	}
	var x = new Ajax();
	username = BROWSER.ie && document.charset == 'utf-8' ? encodeURIComponent(username) : username;
	x.get('forum.php?mod=ajax&inajax=1&action=checkuserexists&username=' + username, function(s){
		var obj = $(objname);
		obj.innerHTML = s;
	});
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if($('postform').affirmpoint.value == '') {
		showDialog('{lang post_debate_message_1}', 'alert', '', function () { $('postform').affirmpoint.focus() });
		return false;
	}
	if($('postform').negapoint.value == '') {
		showDialog('{lang post_debate_message_2}', 'alert', '', function () { $('postform').negapoint.focus() });
		return false;
	}
	return true;
}
</script>